import { HttpStatus, Inject, Injectable } from "@nestjs/common";
import { canCreateProgram, canRestoreProgram, programEntitlement } from "@waflo/billing";
import {
  findProgramTemplate,
  type ProgramCreateInput,
  type ProgramTemplateDefinition,
  type ProgramUpdateInput,
} from "@waflo/contracts";
import type { Prisma } from "@waflo/database";
import { AuditService } from "../audit/audit.service.js";
import { AppError } from "../common/app-error.js";
import {
  withOrganizationCacheLock,
  withOrganizationInvariantLock,
} from "../common/organization-transaction.js";
import {
  decodeNumberCursor,
  decodeTimestampCursor,
  encodeCursor,
} from "../common/cursor-pagination.js";
import type { WafloRequest } from "../common/request-context.js";
import { PrismaService } from "../database/prisma.service.js";
import { TenantService } from "../tenancy/tenant.service.js";
import { createHash } from "node:crypto";
import { renderStampSvg, type StampOutputProfile } from "@waflo/stamp-engine";
import {
  artworkFor,
  canonicalArtworkBytes,
  conceptTemplates,
  LIBRARY_ARTWORK_SCHEMA_VERSION,
  libraryArtworkDigest,
} from "./library-artwork.js";
import { OBJECT_STORAGE, type ObjectStorage } from "./object-storage.js";
import {
  type PreviewAsset,
  previewAssetCacheIdentity,
  resolvePreviewAssetContent,
} from "./preview-assets.js";
import { createProgramPreviewCacheKey, PREVIEW_RENDERER_SCHEMA_VERSION } from "./preview-cache.js";
import { composeProgramPreview } from "./preview-composer.js";
import {
  absoluteTestPosition,
  canRedeemEarnedReward,
  crossedRewardThresholds,
  projectAbsoluteTestPosition,
} from "./program-rules.js";
import { validateProgramConfiguration } from "./validation-engine.js";

const templates = conceptTemplates();

const includeVersion = {
  translations: true,
  stampRule: true,
  rewards: { include: { translations: true, visualOverride: true } },
  locations: { include: { location: true } },
  visualTheme: true,
} as const;

function digest(value: unknown): string {
  return createHash("sha256").update(JSON.stringify(value)).digest("hex");
}

function toPlan(value: "STARTER" | "GROWTH" | "SCALE") {
  return value.toLocaleLowerCase("en-US") as "starter" | "growth" | "scale";
}

function templateFor(code?: string, version?: number) {
  const template =
    (code ? findProgramTemplate(code, version) : templates[0]) ??
    (code && version === undefined ? findProgramTemplate(code) : undefined);
  if (!template)
    throw new AppError(
      "PROGRAM_TEMPLATE_NOT_FOUND",
      "Program template not found.",
      HttpStatus.UNPROCESSABLE_ENTITY,
    );
  return template;
}

function previewTypeFor(profile: StampOutputProfile) {
  return profile === "APPLE_WALLET"
    ? ("APPLE_WALLET_PREVIEW" as const)
    : profile === "GOOGLE_WALLET"
      ? ("GOOGLE_WALLET_PREVIEW" as const)
      : ("CUSTOMER_WEB_CARD" as const);
}

function sha256Bytes(bytes: Buffer): string {
  return createHash("sha256").update(bytes).digest("hex");
}

@Injectable()
export class ProgramsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly tenant: TenantService,
    private readonly audit: AuditService,
    @Inject(OBJECT_STORAGE) private readonly objectStorage: ObjectStorage,
  ) {}

  async list(userId: string, organizationId: string, cursor?: string, limit = 20) {
    await this.tenant.requireMembership(userId, organizationId, "programs.view");
    const decoded = decodeTimestampCursor(cursor);
    const rows = await this.prisma.client.loyaltyProgram.findMany({
      where: {
        organizationId,
        ...(decoded
          ? {
              OR: [
                { updatedAt: { lt: new Date(decoded.timestamp) } },
                { updatedAt: new Date(decoded.timestamp), id: { lt: decoded.id } },
              ],
            }
          : {}),
      },
      orderBy: [{ updatedAt: "desc" }, { id: "desc" }],
      take: limit + 1,
      include: {
        currentDraftVersion: {
          select: {
            id: true,
            versionNumber: true,
            status: true,
            editingMode: true,
            revision: true,
          },
        },
        currentPublishedVersion: {
          select: { id: true, versionNumber: true, status: true, publishedAt: true },
        },
        _count: { select: { versions: true } },
      },
    });
    const items = rows.slice(0, limit);
    const last = rows.length > limit ? items.at(-1) : undefined;
    return {
      items,
      nextCursor: last
        ? encodeCursor({ id: last.id, timestamp: last.updatedAt.toISOString() })
        : null,
    };
  }

  get(userId: string, organizationId: string, programId: string) {
    return this.tenant.requireMembership(userId, organizationId, "programs.view").then(async () => {
      const program = await this.prisma.client.loyaltyProgram.findFirst({
        where: { id: programId, organizationId },
        include: {
          currentDraftVersion: { include: includeVersion },
          currentPublishedVersion: { include: includeVersion },
          versions: { orderBy: { versionNumber: "desc" }, take: 20, include: includeVersion },
        },
      });
      if (!program)
        throw new AppError("PROGRAM_NOT_FOUND", "Program not found.", HttpStatus.NOT_FOUND);
      return program;
    });
  }

  listVersions(
    userId: string,
    organizationId: string,
    programId: string,
    cursor?: string,
    limit = 20,
  ) {
    return this.tenant.requireMembership(userId, organizationId, "programs.view").then(async () => {
      const decoded = decodeNumberCursor(cursor);
      const program = await this.prisma.client.loyaltyProgram.findFirst({
        where: { id: programId, organizationId },
        select: { id: true },
      });
      if (!program)
        throw new AppError("PROGRAM_NOT_FOUND", "Program not found.", HttpStatus.NOT_FOUND);
      const rows = await this.prisma.client.loyaltyProgramVersion.findMany({
        where: {
          programId,
          organizationId,
          ...(decoded
            ? {
                OR: [
                  { versionNumber: { lt: decoded.value } },
                  { versionNumber: decoded.value, id: { lt: decoded.id } },
                ],
              }
            : {}),
        },
        orderBy: [{ versionNumber: "desc" }, { id: "desc" }],
        take: limit + 1,
        select: {
          id: true,
          versionNumber: true,
          status: true,
          editingMode: true,
          revision: true,
          changeSummary: true,
          createdAt: true,
          publishedAt: true,
          supersededAt: true,
          validatedAt: true,
          testReadyAt: true,
        },
      });
      const items = rows.slice(0, limit);
      const last = rows.length > limit ? items.at(-1) : undefined;
      return {
        items,
        nextCursor: last ? encodeCursor({ id: last.id, value: last.versionNumber }) : null,
      };
    });
  }

  version(userId: string, organizationId: string, programId: string, versionId: string) {
    return this.tenant.requireMembership(userId, organizationId, "programs.view").then(async () => {
      const result = await this.prisma.client.loyaltyProgramVersion.findFirst({
        where: { id: versionId, programId, organizationId },
        include: includeVersion,
      });
      if (!result)
        throw new AppError(
          "PROGRAM_VERSION_NOT_FOUND",
          "Program version not found.",
          HttpStatus.NOT_FOUND,
        );
      return result;
    });
  }

  templates(userId: string, organizationId: string) {
    return this.tenant.requireMembership(userId, organizationId, "programs.view").then(() =>
      templates.map((template) => ({
        ...template,
        artwork: {
          filled: {
            ...template.artwork.filled,
            previewUrl: `data:image/svg+xml;base64,${Buffer.from(artworkFor(template.artwork.filled)?.content ?? "", "utf8").toString("base64")}`,
          },
          empty: {
            ...template.artwork.empty,
            previewUrl: `data:image/svg+xml;base64,${Buffer.from(artworkFor(template.artwork.empty)?.content ?? "", "utf8").toString("base64")}`,
          },
          milestone: {
            ...template.artwork.milestone,
            previewUrl: `data:image/svg+xml;base64,${Buffer.from(artworkFor(template.artwork.milestone)?.content ?? "", "utf8").toString("base64")}`,
          },
        },
      })),
    );
  }

  async preview(
    userId: string,
    organizationId: string,
    programId: string,
    progress: number,
    outputProfile: StampOutputProfile = "CUSTOMER_WEB",
    locale: "EN" | "AR" = "EN",
  ) {
    await this.tenant.requireMembership(userId, organizationId, "programs.view");
    return withOrganizationCacheLock(this.prisma.client, organizationId, async (transaction) => {
      const program = await transaction.loyaltyProgram.findFirst({
        where: { id: programId, organizationId },
        include: {
          currentDraftVersion: {
            include: {
              translations: true,
              stampRule: true,
              rewards: {
                include: {
                  translations: true,
                  visualOverride: { include: { stampAsset: { include: { variants: true } } } },
                },
              },
              visualTheme: {
                include: {
                  filledStampAsset: { include: { variants: true } },
                  emptyStampAsset: { include: { variants: true } },
                  defaultMilestoneAsset: { include: { variants: true } },
                  logoAsset: { include: { variants: true } },
                  heroAsset: { include: { variants: true } },
                  backgroundAsset: { include: { variants: true } },
                },
              },
            },
          },
          currentPublishedVersion: {
            include: {
              translations: true,
              stampRule: true,
              rewards: {
                include: {
                  translations: true,
                  visualOverride: { include: { stampAsset: { include: { variants: true } } } },
                },
              },
              visualTheme: {
                include: {
                  filledStampAsset: { include: { variants: true } },
                  emptyStampAsset: { include: { variants: true } },
                  defaultMilestoneAsset: { include: { variants: true } },
                  logoAsset: { include: { variants: true } },
                  heroAsset: { include: { variants: true } },
                  backgroundAsset: { include: { variants: true } },
                },
              },
            },
          },
        },
      });
      const version = program?.currentDraftVersion ?? program?.currentPublishedVersion;
      if (!program || !version)
        throw new AppError(
          "PROGRAM_VERSION_NOT_FOUND",
          "Program version not found.",
          HttpStatus.NOT_FOUND,
        );
      const goal = version.stampRule?.requiredStampCount ?? 8;
      const visual = version.visualTheme;
      const safeProgress = Math.max(0, Math.min(goal, progress));
      const safeLayout = visual?.layoutType ?? "GRID";
      const previewType = previewTypeFor(outputProfile);
      const configurationFingerprint = digest({
        versionId: version.id,
        revision: version.revision,
      });
      const previewCacheKey = createProgramPreviewCacheKey({
        rendererSchemaVersion: PREVIEW_RENDERER_SCHEMA_VERSION,
        template: {
          code: version.baseTemplateCode,
          version: version.baseTemplateVersion,
        },
        version: { id: version.id, revision: version.revision },
        progress: safeProgress,
        locale,
        profile: outputProfile,
        goal,
        translations: version.translations
          .toSorted((left, right) => left.locale.localeCompare(right.locale))
          .map((item) => ({
            locale: item.locale,
            programName: item.programName,
            shortDescription: item.shortDescription,
            rewardSummary: item.rewardSummary,
            termsAndConditions: item.termsAndConditions,
          })),
        rewards: version.rewards
          .toSorted((left, right) => left.id.localeCompare(right.id))
          .map((reward) => ({
            id: reward.id,
            threshold: reward.thresholdStampCount,
            internalName: reward.internalName,
            translations: reward.translations.toSorted((left, right) =>
              left.locale.localeCompare(right.locale),
            ),
            asset: previewAssetCacheIdentity(reward.visualOverride?.stampAsset, "STAMP_256"),
          })),
        visual: visual
          ? {
              colors: [
                visual.backgroundColor,
                visual.foregroundColor,
                visual.accentColor,
                visual.secondaryColor,
                visual.mutedColor,
              ],
              layout: visual.layoutType,
              layoutConfiguration: visual.layoutConfiguration,
              stampSize: visual.stampSize,
              stampSpacing: visual.stampSpacing,
              progressLabelVisible: visual.progressLabelVisible,
              rewardLabelVisible: visual.rewardLabelVisible,
              customerWebVariant: visual.customerWebVariant,
              applePreviewConfig: visual.applePreviewConfig,
              googlePreviewConfig: visual.googlePreviewConfig,
            }
          : null,
        assets: {
          filled: previewAssetCacheIdentity(visual?.filledStampAsset, "STAMP_256"),
          empty: previewAssetCacheIdentity(visual?.emptyStampAsset, "STAMP_256"),
          milestone: previewAssetCacheIdentity(visual?.defaultMilestoneAsset, "STAMP_256"),
          logo: previewAssetCacheIdentity(visual?.logoAsset, "ORIGINAL_SAFE"),
          hero: previewAssetCacheIdentity(visual?.heroAsset, "ORIGINAL_SAFE"),
          background: previewAssetCacheIdentity(visual?.backgroundAsset, "ORIGINAL_SAFE"),
        },
      });
      const cached = await transaction.generatedProgramPreview.findUnique({
        where: {
          versionId_previewType_progressState_configurationHash: {
            versionId: version.id,
            previewType,
            progressState: safeProgress,
            configurationHash: previewCacheKey,
          },
        },
      });
      if (cached) {
        let cachedBytes: Buffer;
        try {
          cachedBytes = await this.objectStorage.get(cached.objectKey);
        } catch {
          throw new AppError(
            "PROGRAM_PREVIEW_CONTENT_UNAVAILABLE",
            "The cached preview content is unavailable.",
            HttpStatus.SERVICE_UNAVAILABLE,
            { previewId: cached.id },
          );
        }
        const cachedDigest = sha256Bytes(cachedBytes);
        if (cached.contentDigest !== cachedDigest)
          throw new AppError(
            "PROGRAM_PREVIEW_CONTENT_UNAVAILABLE",
            "The cached preview content failed its integrity check.",
            HttpStatus.SERVICE_UNAVAILABLE,
            { previewId: cached.id },
          );
        await transaction.generatedProgramPreview.update({
          where: { id: cached.id },
          data: { lastAccessedAt: new Date() },
        });
        await transaction.loyaltyProgramVersion.updateMany({
          where: { id: version.id, revision: version.revision },
          data: { renderFingerprint: configurationFingerprint },
        });
        return {
          ...cached,
          svg: cachedBytes.toString("utf8"),
          digest: cachedDigest,
          warnings: cached.warnings,
          profile: outputProfile,
          locale,
          cacheStatus: "HIT" as const,
        };
      }
      const assetData = (
        asset: PreviewAsset | null | undefined,
        preferredVariant: "STAMP_256" | "ORIGINAL_SAFE",
        role: string,
        required = false,
      ) => resolvePreviewAssetContent(this.objectStorage, asset, preferredVariant, role, required);
      const [
        filledAsset,
        emptyAsset,
        defaultMilestoneAsset,
        logoAsset,
        heroAsset,
        backgroundAsset,
      ] = await Promise.all([
        assetData(visual?.filledStampAsset, "STAMP_256", "filled stamp", true),
        assetData(visual?.emptyStampAsset, "STAMP_256", "empty stamp", true),
        assetData(visual?.defaultMilestoneAsset, "STAMP_256", "default milestone"),
        assetData(visual?.logoAsset, "ORIGINAL_SAFE", "logo"),
        assetData(visual?.heroAsset, "ORIGINAL_SAFE", "hero"),
        assetData(visual?.backgroundAsset, "ORIGINAL_SAFE", "background"),
      ]);
      const rewardMilestoneAssets = await Promise.all(
        version.rewards.map(async (reward) => ({
          reward,
          asset:
            (await assetData(
              reward.visualOverride?.stampAsset,
              "STAMP_256",
              `reward milestone ${reward.id}`,
            )) ?? defaultMilestoneAsset,
        })),
      );
      const translation =
        version.translations.find((item) => item.locale === locale) ??
        version.translations.find((item) => item.locale === "EN");
      if (!translation)
        throw new AppError(
          "PROGRAM_TRANSLATION_NOT_FOUND",
          "Program translation not found.",
          HttpStatus.UNPROCESSABLE_ENTITY,
        );
      const visualInput = visual ?? {
        backgroundColor: "#F7F4EE",
        foregroundColor: "#222222",
        accentColor: "#E4572E",
        secondaryColor: "#F3A712",
        layoutConfiguration: {},
        stampSize: 48,
        stampSpacing: 8,
        progressLabelVisible: true,
        rewardLabelVisible: true,
        customerWebVariant: "CARD",
        applePreviewConfig: {},
        googlePreviewConfig: {},
      };
      const rendered = renderStampSvg({
        goal,
        progress: safeProgress,
        layout: safeLayout,
        layoutConfiguration: visualInput.layoutConfiguration as {
          columns?: number;
          maxPerRow?: number;
          serpentine?: boolean;
          startAngle?: number;
        },
        outputProfile,
        filledColor: visualInput.accentColor,
        emptyColor: visualInput.backgroundColor,
        accentColor: visualInput.foregroundColor,
        backgroundColor: visualInput.backgroundColor,
        foregroundColor: visualInput.foregroundColor,
        stampSize: visualInput.stampSize,
        spacing: visualInput.stampSpacing,
        ...(filledAsset ? { filledArtwork: filledAsset.artwork } : {}),
        ...(emptyAsset ? { emptyArtwork: emptyAsset.artwork } : {}),
        milestones: rewardMilestoneAssets.flatMap(({ reward, asset }) =>
          asset
            ? [
                {
                  position: reward.thresholdStampCount,
                  artwork: asset.artwork,
                  label:
                    reward.translations.find((item) => item.locale === locale)?.name ??
                    reward.internalName,
                },
              ]
            : [],
        ),
        label: `${safeProgress}/${goal}`,
        rewardLabel: translation.rewardSummary,
        progressLabelVisible: visualInput.progressLabelVisible,
        rewardLabelVisible: visualInput.rewardLabelVisible,
      });
      const appleConfig = visualInput.applePreviewConfig as Partial<{
        headerLabel: string;
        headerValue: string;
        secondaryLabel: string;
        barcodeLabel: string;
        showBackContent: boolean;
      }>;
      const googleConfig = visualInput.googlePreviewConfig as Partial<{
        title: string;
        subtitle: string;
        detailsLabel: string;
        barcodeLabel: string;
      }>;
      const composed = composeProgramPreview({
        profile: outputProfile,
        locale,
        programName: translation.programName,
        shortDescription: translation.shortDescription,
        rewardSummary: translation.rewardSummary,
        terms: translation.termsAndConditions,
        progress: safeProgress,
        goal,
        stampSvg: rendered.svg,
        backgroundColor: visualInput.backgroundColor,
        foregroundColor: visualInput.foregroundColor,
        accentColor: visualInput.accentColor,
        secondaryColor: visualInput.secondaryColor,
        ...(logoAsset ? { logoDataUri: logoAsset.dataUri } : {}),
        ...(heroAsset ? { heroDataUri: heroAsset.dataUri } : {}),
        ...(backgroundAsset ? { backgroundDataUri: backgroundAsset.dataUri } : {}),
        customerWebVariant: visualInput.customerWebVariant as "CARD" | "MINIMAL" | "HERO",
        apple: {
          headerLabel: appleConfig.headerLabel ?? "REWARDS",
          headerValue: appleConfig.headerValue ?? program.internalName,
          secondaryLabel: appleConfig.secondaryLabel ?? "NEXT REWARD",
          barcodeLabel: appleConfig.barcodeLabel ?? "Preview barcode",
          showBackContent: appleConfig.showBackContent ?? true,
        },
        google: {
          title: googleConfig.title ?? translation.programName,
          subtitle: googleConfig.subtitle ?? translation.shortDescription,
          detailsLabel: googleConfig.detailsLabel ?? "Reward progress",
          barcodeLabel: googleConfig.barcodeLabel ?? "Preview barcode",
        },
      });
      const objectKey = `organizations/${organizationId}/previews/${version.id}/${outputProfile.toLowerCase()}-${locale.toLowerCase()}-${previewCacheKey}.svg`;
      await this.objectStorage.ensureReady();
      const previewBytes = Buffer.from(composed.svg);
      const storageResult = await this.objectStorage.putImmutable(
        objectKey,
        previewBytes,
        "image/svg+xml",
      );
      if (storageResult === "EXISTS") {
        const existingBytes = await this.objectStorage.get(objectKey);
        if (sha256Bytes(existingBytes) !== composed.digest)
          throw new AppError(
            "PROGRAM_PREVIEW_CONTENT_CONFLICT",
            "An immutable preview key already contains different content.",
            HttpStatus.CONFLICT,
          );
      }
      const renderUpdate = await transaction.loyaltyProgramVersion.updateMany({
        where: {
          id: version.id,
          revision: version.revision,
          OR: [
            { renderFingerprint: null },
            { renderFingerprint: { not: configurationFingerprint } },
          ],
        },
        data: { renderFingerprint: configurationFingerprint },
      });
      if (renderUpdate.count === 0) {
        const latestVersion = await transaction.loyaltyProgramVersion.findUniqueOrThrow({
          where: { id: version.id },
          select: { revision: true, renderFingerprint: true },
        });
        if (
          latestVersion.revision !== version.revision ||
          latestVersion.renderFingerprint !== configurationFingerprint
        ) {
          await this.objectStorage.delete(objectKey);
          throw new AppError(
            "PREVIEW_DRAFT_CHANGED",
            "The draft changed while this preview was rendering. Generate it again.",
            HttpStatus.CONFLICT,
          );
        }
      }
      const preview = await transaction.generatedProgramPreview.create({
        data: {
          organizationId,
          versionId: version.id,
          versionRevision: version.revision,
          previewType,
          progressState: safeProgress,
          configurationHash: previewCacheKey,
          contentDigest: composed.digest,
          warnings: composed.warnings,
          objectKey,
          mimeType: "image/svg+xml",
          width: composed.width,
          height: composed.height,
        },
      });
      return {
        ...preview,
        svg: composed.svg,
        digest: composed.digest,
        warnings: composed.warnings,
        profile: outputProfile,
        locale,
        cacheStatus: "MISS" as const,
      };
    });
  }

  async create(
    userId: string,
    organizationId: string,
    input: ProgramCreateInput,
    request: WafloRequest,
  ) {
    await this.tenant.requireMembership(userId, organizationId, "programs.create");
    return withOrganizationInvariantLock(
      this.prisma.client,
      organizationId,
      async (transaction) => {
        const organization = await transaction.organization.findUniqueOrThrow({
          where: { id: organizationId },
        });
        const usage = await transaction.loyaltyProgram.count({
          where: { organizationId, status: { not: "ARCHIVED" } },
        });
        const plan = toPlan(organization.selectedPlan);
        const decision = canCreateProgram(plan, usage);
        if (!decision.allowed) {
          throw new AppError(
            "PROGRAM_LIMIT_REACHED",
            "Your plan has reached its active program limit.",
            HttpStatus.CONFLICT,
            {
              limit: decision.limit,
              currentUsage: decision.currentUsage,
              recommendedPlan: decision.recommendedPlan,
            },
          );
        }
        const locations = await transaction.location.findMany({
          where: { id: { in: input.locationIds }, organizationId, status: "ACTIVE" },
          select: { id: true },
        });
        if (locations.length !== input.locationIds.length) {
          throw new AppError(
            "PROGRAM_LOCATION_INVALID",
            "Select active locations from this organization.",
            HttpStatus.UNPROCESSABLE_ENTITY,
          );
        }
        if (!programEntitlement(plan, "canUseProMode") && input.editingMode === "pro") {
          throw new AppError(
            "PROGRAM_PRO_MODE_UNAVAILABLE",
            "Pro Mode requires Growth or Scale.",
            HttpStatus.FORBIDDEN,
            { recommendedPlan: "growth" },
          );
        }
        if (input.rewards.length > 1 && !programEntitlement(plan, "canUseMultipleRewards")) {
          throw new AppError(
            "PROGRAM_MULTIPLE_REWARDS_UNAVAILABLE",
            "Multiple rewards require Growth or Scale.",
            HttpStatus.FORBIDDEN,
            { recommendedPlan: "growth" },
          );
        }
        if (
          input.rewards.some((reward) => reward.thresholdStampCount < input.requiredStampCount) &&
          !programEntitlement(plan, "canUseMilestoneRewards")
        ) {
          throw new AppError(
            "PROGRAM_MILESTONES_UNAVAILABLE",
            "Milestone rewards require Growth or Scale.",
            HttpStatus.FORBIDDEN,
            { recommendedPlan: "growth" },
          );
        }
        if (
          ["PATH", "RING"].includes(input.visualTheme.layoutType) &&
          !programEntitlement(plan, "canUseAdvancedLayouts")
        ) {
          throw new AppError(
            "PROGRAM_ADVANCED_LAYOUT_UNAVAILABLE",
            "Advanced layouts require Growth or Scale.",
            HttpStatus.FORBIDDEN,
            { recommendedPlan: "growth" },
          );
        }
        const selectedTemplate = templateFor(input.templateCode, input.templateVersion);
        const themeAssets = await this.ensureBuiltInAssets(
          transaction,
          organizationId,
          userId,
          selectedTemplate,
        );
        await this.assertAssetReferences(
          transaction,
          organizationId,
          input.visualTheme,
          input.rewards,
        );
        const versionData = this.versionCreateData(
          input,
          themeAssets,
          locations.map((location) => location.id),
          userId,
          selectedTemplate,
        );
        const program = await transaction.loyaltyProgram.create({
          data: {
            organizationId,
            internalName: input.internalName,
            programType: "STAMP",
            status: "DRAFT",
            createdByUserId: userId,
            versions: { create: { ...versionData, versionNumber: 1, organizationId } as never },
          },
        });
        const version = await transaction.loyaltyProgramVersion.findFirst({
          where: { programId: program.id },
          orderBy: { versionNumber: "desc" },
          include: includeVersion,
        });
        if (!version)
          throw new AppError(
            "PROGRAM_CREATE_FAILED",
            "Unable to create program.",
            HttpStatus.INTERNAL_SERVER_ERROR,
          );
        const updated = await transaction.loyaltyProgram.update({
          where: { id: program.id },
          data: { currentDraftVersionId: version.id },
        });
        await this.audit.record(
          {
            organizationId,
            actorUserId: userId,
            action: "program.created",
            targetType: "loyalty_program",
            targetId: program.id,
            metadata: {
              versionId: version.id,
              templateCode: selectedTemplate.code,
              templateVersion: selectedTemplate.version,
            },
          },
          request,
        );
        return { ...updated, currentDraftVersion: version };
      },
    );
  }

  async update(
    userId: string,
    organizationId: string,
    programId: string,
    input: ProgramUpdateInput,
    request: WafloRequest,
  ) {
    await this.tenant.requireMembership(userId, organizationId, "programs.edit");
    return withOrganizationInvariantLock(
      this.prisma.client,
      organizationId,
      async (transaction) => {
        const program = await transaction.loyaltyProgram.findFirst({
          where: { id: programId, organizationId },
          include: { currentDraftVersion: { include: includeVersion } },
        });
        if (!program)
          throw new AppError("PROGRAM_NOT_FOUND", "Program not found.", HttpStatus.NOT_FOUND);
        if (
          !program.currentDraftVersion ||
          ["PUBLISHED", "SUPERSEDED", "ABANDONED"].includes(program.currentDraftVersion.status)
        ) {
          throw new AppError(
            "PROGRAM_DRAFT_REQUIRED",
            "Create a draft version before editing.",
            HttpStatus.CONFLICT,
          );
        }
        if (program.currentDraftVersion.revision !== input.revision) {
          throw new AppError(
            "STALE_PROGRAM_DRAFT",
            "This draft changed in another editor. Reload before saving.",
            HttpStatus.CONFLICT,
            {
              expectedRevision: program.currentDraftVersion.revision,
              receivedRevision: input.revision,
            },
          );
        }
        if (input.locationIds) {
          const locations = await transaction.location.count({
            where: { id: { in: input.locationIds }, organizationId, status: "ACTIVE" },
          });
          if (locations !== input.locationIds.length)
            throw new AppError(
              "PROGRAM_LOCATION_INVALID",
              "Select active locations from this organization.",
              HttpStatus.UNPROCESSABLE_ENTITY,
            );
        }
        const current = program.currentDraftVersion;
        const next = {
          ...this.inputFromVersion(current, program.internalName),
          ...input,
        } as ProgramCreateInput & { changeSummary?: string };
        const organization = await transaction.organization.findUniqueOrThrow({
          where: { id: organizationId },
          select: { selectedPlan: true },
        });
        const plan = toPlan(organization.selectedPlan);
        if (!programEntitlement(plan, "canUseProMode") && next.editingMode === "pro")
          throw new AppError(
            "PROGRAM_PRO_MODE_UNAVAILABLE",
            "Pro Mode requires Growth or Scale.",
            HttpStatus.FORBIDDEN,
            { recommendedPlan: "growth" },
          );
        if (next.rewards.length > 1 && !programEntitlement(plan, "canUseMultipleRewards"))
          throw new AppError(
            "PROGRAM_MULTIPLE_REWARDS_UNAVAILABLE",
            "Multiple rewards require Growth or Scale.",
            HttpStatus.FORBIDDEN,
            { recommendedPlan: "growth" },
          );
        if (
          next.rewards.some((reward) => reward.thresholdStampCount < next.requiredStampCount) &&
          !programEntitlement(plan, "canUseMilestoneRewards")
        )
          throw new AppError(
            "PROGRAM_MILESTONES_UNAVAILABLE",
            "Milestone rewards require Growth or Scale.",
            HttpStatus.FORBIDDEN,
            { recommendedPlan: "growth" },
          );
        if (
          ["PATH", "RING"].includes(next.visualTheme.layoutType) &&
          !programEntitlement(plan, "canUseAdvancedLayouts")
        )
          throw new AppError(
            "PROGRAM_ADVANCED_LAYOUT_UNAVAILABLE",
            "Advanced layouts require Growth or Scale.",
            HttpStatus.FORBIDDEN,
            { recommendedPlan: "growth" },
          );
        await this.assertAssetReferences(
          transaction,
          organizationId,
          next.visualTheme,
          next.rewards,
        );
        await this.clearDraftChildren(transaction, current.id);
        const selectedTemplate = templateFor(
          next.templateCode ?? current.baseTemplateCode ?? undefined,
          next.templateVersion ?? current.baseTemplateVersion ?? undefined,
        );
        const assets = await this.ensureBuiltInAssets(
          transaction,
          organizationId,
          userId,
          selectedTemplate,
        );
        const versionData = this.versionCreateData(
          next,
          assets,
          next.locationIds ?? current.locations.map((item) => item.locationId),
          userId,
          selectedTemplate,
        );
        await transaction.loyaltyProgramVersion.update({
          where: { id: current.id },
          data: {
            ...versionData,
            revision: { increment: 1 },
            status: "DRAFT",
            validatedAt: null,
            testReadyAt: null,
            validationFingerprint: null,
            renderFingerprint: null,
            changeSummary: next.changeSummary ?? null,
          } as never,
        });
        const updated = await transaction.loyaltyProgram.update({
          where: { id: programId },
          data: { internalName: next.internalName, revision: { increment: 1 } },
          include: { currentDraftVersion: { include: includeVersion } },
        });
        await this.audit.record(
          {
            organizationId,
            actorUserId: userId,
            action: "program.draft_updated",
            targetType: "loyalty_program_version",
            targetId: current.id,
            metadata: { revision: current.revision + 1 },
          },
          request,
        );
        return updated;
      },
    );
  }

  async createDraft(
    userId: string,
    organizationId: string,
    programId: string,
    _request: WafloRequest,
  ) {
    await this.tenant.requireMembership(userId, organizationId, "programs.edit");
    return withOrganizationInvariantLock(
      this.prisma.client,
      organizationId,
      async (transaction) => {
        const program = await transaction.loyaltyProgram.findFirst({
          where: { id: programId, organizationId },
          include: {
            currentPublishedVersion: { include: includeVersion },
            currentDraftVersion: true,
          },
        });
        if (!program)
          throw new AppError("PROGRAM_NOT_FOUND", "Program not found.", HttpStatus.NOT_FOUND);
        if (program.currentDraftVersion) return program;
        if (!program.currentPublishedVersion)
          throw new AppError(
            "PROGRAM_DRAFT_REQUIRED",
            "Program has no published version to copy.",
            HttpStatus.CONFLICT,
          );
        const source = program.currentPublishedVersion;
        const data = await this.cloneVersionData(transaction, source.id, userId);
        const version = await transaction.loyaltyProgramVersion.create({
          data: {
            ...data,
            programId,
            organizationId,
            versionNumber: program.latestVersionNumber + 1,
            createdByUserId: userId,
            status: "DRAFT",
            publishedAt: null,
            supersededAt: null,
          } as never,
        });
        return transaction.loyaltyProgram.update({
          where: { id: programId },
          data: { currentDraftVersionId: version.id, latestVersionNumber: { increment: 1 } },
          include: {
            currentDraftVersion: { include: includeVersion },
            currentPublishedVersion: { include: includeVersion },
          },
        });
      },
    );
  }

  async validate(userId: string, organizationId: string, programId: string, request: WafloRequest) {
    await this.tenant.requireMembership(userId, organizationId, "programs.validate");
    const result = await withOrganizationInvariantLock(
      this.prisma.client,
      organizationId,
      async (transaction) => {
        const program = await transaction.loyaltyProgram.findFirst({
          where: { id: programId, organizationId },
          include: {
            organization: { select: { selectedPlan: true } },
            currentDraftVersion: {
              include: {
                translations: true,
                stampRule: true,
                rewards: {
                  include: {
                    translations: true,
                    visualOverride: { include: { stampAsset: true } },
                  },
                },
                locations: { include: { location: true } },
                visualTheme: {
                  include: {
                    logoAsset: true,
                    heroAsset: true,
                    backgroundAsset: true,
                    filledStampAsset: true,
                    emptyStampAsset: true,
                    defaultMilestoneAsset: true,
                  },
                },
                testSessions: {
                  where: { status: "COMPLETED" },
                  select: {
                    versionRevision: true,
                    validationFingerprint: true,
                  },
                },
                previews: {
                  select: {
                    previewType: true,
                    versionRevision: true,
                  },
                },
              },
            },
          },
        });
        if (!program?.currentDraftVersion)
          throw new AppError(
            "PROGRAM_DRAFT_REQUIRED",
            "Create a draft before validating.",
            HttpStatus.CONFLICT,
          );
        const version = program.currentDraftVersion;
        const fingerprint = digest({
          versionId: version.id,
          revision: version.revision,
        });
        const visual = version.visualTheme;
        const { errors, warnings } = validateProgramConfiguration({
          plan: program.organization.selectedPlan,
          goal: version.stampRule?.requiredStampCount ?? 0,
          translations: version.translations,
          rewards: version.rewards.map((reward) => ({
            thresholdStampCount: reward.thresholdStampCount,
            maximumRedemptionsPerEarned: reward.maximumRedemptionsPerEarned,
            stampAsset: reward.visualOverride?.stampAsset ?? null,
          })),
          locations: version.locations.map((location) => ({
            status: location.location.status,
          })),
          visual: visual
            ? {
                backgroundColor: visual.backgroundColor,
                foregroundColor: visual.foregroundColor,
                accentColor: visual.accentColor,
                layoutType: visual.layoutType,
                stampSize: visual.stampSize,
                stampSpacing: visual.stampSpacing,
                applePreviewConfig: visual.applePreviewConfig,
                googlePreviewConfig: visual.googlePreviewConfig,
                assets: [
                  {
                    role: "filledStamp",
                    expectedCategory: "STAMP_FILLED",
                    asset: visual.filledStampAsset,
                    required: true,
                  },
                  {
                    role: "emptyStamp",
                    expectedCategory: "STAMP_EMPTY",
                    asset: visual.emptyStampAsset,
                    required: true,
                  },
                  {
                    role: "logo",
                    expectedCategory: "LOGO",
                    asset: visual.logoAsset,
                    required: false,
                  },
                  {
                    role: "hero",
                    expectedCategory: "HERO",
                    asset: visual.heroAsset,
                    required: false,
                  },
                  {
                    role: "background",
                    expectedCategory: "BACKGROUND",
                    asset: visual.backgroundAsset,
                    required: false,
                  },
                  {
                    role: "milestone",
                    expectedCategory: "STAMP_MILESTONE",
                    asset: visual.defaultMilestoneAsset,
                    required: false,
                  },
                ],
              }
            : null,
          expectedFingerprint: fingerprint,
          renderFingerprint: version.renderFingerprint,
          previewProfiles: version.previews
            .filter((preview) => preview.versionRevision === version.revision)
            .map((preview) => preview.previewType),
          completedTestSessions: version.testSessions,
          versionRevision: version.revision,
        });
        const status = errors.length
          ? "FAILED"
          : warnings.length
            ? "VALID_WITH_WARNINGS"
            : "PASSED";
        const run = await transaction.programValidationRun.create({
          data: {
            organizationId,
            versionId: version.id,
            status,
            configurationFingerprint: fingerprint,
            errors: errors as unknown as Prisma.InputJsonValue,
            warnings: warnings as unknown as Prisma.InputJsonValue,
            createdByUserId: userId,
          },
        });
        await transaction.loyaltyProgramVersion.update({
          where: { id: version.id },
          data: {
            status: errors.length ? "DRAFT" : "VALIDATED",
            validatedAt: errors.length ? null : new Date(),
            validationFingerprint: fingerprint,
          },
        });
        if (
          !errors.length &&
          !["PUBLISHED", "PAUSED", "ARCHIVED", "SUSPENDED"].includes(program.status)
        )
          await transaction.loyaltyProgram.update({
            where: { id: programId },
            data: { status: "VALIDATED" },
          });
        return { ...run, errors, warnings };
      },
    );
    await this.audit.record(
      {
        organizationId,
        actorUserId: userId,
        action: "program.validated",
        targetType: "loyalty_program",
        targetId: programId,
        metadata: { status: result.status },
      },
      request,
    );
    return result;
  }

  async createTestSession(
    userId: string,
    organizationId: string,
    programId: string,
    request: WafloRequest,
  ) {
    await this.tenant.requireMembership(userId, organizationId, "programs.test");
    const program = await this.prisma.client.loyaltyProgram.findFirst({
      where: { id: programId, organizationId },
      include: { currentDraftVersion: true },
    });
    if (
      !program?.currentDraftVersion ||
      !["VALIDATED", "TEST_READY"].includes(program.currentDraftVersion.status)
    )
      throw new AppError(
        "PROGRAM_NOT_TEST_READY",
        "Validate the draft before entering Test Mode.",
        HttpStatus.CONFLICT,
      );
    const session = await this.prisma.client.programTestSession.create({
      data: {
        organizationId,
        versionId: program.currentDraftVersion.id,
        createdByUserId: userId,
        syntheticDisplayName: "Waflo test customer",
        versionRevision: program.currentDraftVersion.revision,
        validationFingerprint: program.currentDraftVersion.validationFingerprint,
      },
      include: {
        version: {
          include: {
            stampRule: true,
            rewards: { include: { translations: true } },
          },
        },
        events: true,
      },
    });
    await this.audit.record(
      {
        organizationId,
        actorUserId: userId,
        action: "program.test_session_started",
        targetType: "program_test_session",
        targetId: session.id,
      },
      request,
    );
    return session;
  }

  async getTestSession(userId: string, organizationId: string, sessionId: string) {
    await this.tenant.requireMembership(userId, organizationId, "programs.test");
    const session = await this.prisma.client.programTestSession.findFirst({
      where: { id: sessionId, organizationId },
      include: {
        version: {
          include: {
            stampRule: true,
            rewards: { include: { translations: true } },
          },
        },
        events: { orderBy: { createdAt: "desc" }, take: 100 },
      },
    });
    if (!session)
      throw new AppError("TEST_SESSION_NOT_FOUND", "Test session not found.", HttpStatus.NOT_FOUND);
    return session;
  }

  async addTestStamps(
    userId: string,
    organizationId: string,
    sessionId: string,
    amount: number,
    idempotencyKey: string,
    request: WafloRequest,
  ) {
    await this.tenant.requireMembership(userId, organizationId, "programs.test");
    const result = await withOrganizationInvariantLock(
      this.prisma.client,
      organizationId,
      async (transaction) => {
        const session = await transaction.programTestSession.findFirst({
          where: { id: sessionId, organizationId },
          include: { version: { include: { stampRule: true, rewards: true } } },
        });
        if (!session)
          throw new AppError(
            "TEST_SESSION_NOT_FOUND",
            "Test session not found.",
            HttpStatus.NOT_FOUND,
          );
        const existing = await transaction.programTestEvent.findUnique({
          where: { sessionId_idempotencyKey: { sessionId, idempotencyKey } },
        });
        if (existing)
          return transaction.programTestSession.findUniqueOrThrow({
            where: { id: sessionId },
            include: {
              version: {
                include: {
                  stampRule: true,
                  rewards: { include: { translations: true } },
                },
              },
              events: { orderBy: { createdAt: "desc" }, take: 100 },
            },
          });
        if (session.version.revision !== session.versionRevision)
          throw new AppError(
            "TEST_SESSION_STALE",
            "This Test Mode session belongs to an older draft revision.",
            HttpStatus.CONFLICT,
          );
        const goal = session.version.stampRule?.requiredStampCount ?? 8;
        const previousAbsolute = absoluteTestPosition(
          session.cycleCount,
          session.currentStampCount,
          goal,
        );
        const nextAbsolute = previousAbsolute + amount;
        const projection = projectAbsoluteTestPosition(nextAbsolute, goal);
        const crossed = crossedRewardThresholds(
          previousAbsolute,
          amount,
          goal,
          session.version.rewards,
        );
        await transaction.programTestEvent.create({
          data: {
            sessionId,
            eventType: "TEST_STAMP_EARNED",
            amount,
            idempotencyKey,
            createdByUserId: userId,
            safeMetadata: {
              previousAbsolute,
              nextAbsolute,
              previousCycle: session.cycleCount,
              nextCycle: projection.cycleCount,
            },
          },
        });
        for (const threshold of crossed)
          await transaction.programTestEvent.create({
            data: {
              sessionId,
              eventType: "TEST_REWARD_UNLOCKED",
              amount: 1,
              rewardDefinitionId: threshold.rewardId,
              idempotencyKey: `${idempotencyKey}:unlock:${threshold.cycle}:${threshold.rewardId}`,
              createdByUserId: userId,
              safeMetadata: {
                cycle: threshold.cycle,
                thresholdStampCount: threshold.thresholdStampCount,
                absolutePosition: threshold.absolutePosition,
              },
            },
          });
        return transaction.programTestSession.update({
          where: { id: sessionId },
          data: {
            currentStampCount: projection.currentStampCount,
            cycleCount: projection.cycleCount,
            status: "ACTIVE",
          },
          include: {
            version: {
              include: {
                stampRule: true,
                rewards: { include: { translations: true } },
              },
            },
            events: { orderBy: { createdAt: "desc" }, take: 100 },
          },
        });
      },
    );
    await this.audit.record(
      {
        organizationId,
        actorUserId: userId,
        action: "program.test_stamps_added",
        targetType: "program_test_session",
        targetId: sessionId,
        metadata: { amount },
      },
      request,
    );
    return result;
  }

  async redeemTestReward(
    userId: string,
    organizationId: string,
    sessionId: string,
    rewardId: string,
    idempotencyKey: string,
    _request: WafloRequest,
  ) {
    await this.tenant.requireMembership(userId, organizationId, "programs.test");
    return withOrganizationInvariantLock(
      this.prisma.client,
      organizationId,
      async (transaction) => {
        const session = await transaction.programTestSession.findFirst({
          where: { id: sessionId, organizationId },
          include: { version: { include: { rewards: true } } },
        });
        const reward = session?.version.rewards.find((item) => item.id === rewardId);
        if (!session || !reward)
          throw new AppError(
            "TEST_REWARD_NOT_FOUND",
            "Test reward not found.",
            HttpStatus.NOT_FOUND,
          );
        const existing = await transaction.programTestEvent.findUnique({
          where: { sessionId_idempotencyKey: { sessionId, idempotencyKey } },
        });
        if (existing) return existing;
        const latestReset = await transaction.programTestEvent.findFirst({
          where: { sessionId, eventType: "TEST_SESSION_RESET" },
          orderBy: { createdAt: "desc" },
          select: { createdAt: true },
        });
        const sinceReset = latestReset ? { createdAt: { gt: latestReset.createdAt } } : {};
        const rewardEvents = await transaction.programTestEvent.findMany({
          where: {
            sessionId,
            rewardDefinitionId: rewardId,
            eventType: {
              in: ["TEST_REWARD_UNLOCKED", "TEST_REWARD_RELOCKED", "TEST_REWARD_REDEEMED"],
            },
            ...sinceReset,
          },
          orderBy: { createdAt: "asc" },
        });
        const cycleCounts = new Map<
          number,
          { unlocked: number; relocked: number; redeemed: number }
        >();
        for (const rewardEvent of rewardEvents) {
          const metadata =
            rewardEvent.safeMetadata && typeof rewardEvent.safeMetadata === "object"
              ? (rewardEvent.safeMetadata as { cycle?: unknown })
              : null;
          const cycle = typeof metadata?.cycle === "number" ? metadata.cycle : 1;
          const counts = cycleCounts.get(cycle) ?? {
            unlocked: 0,
            relocked: 0,
            redeemed: 0,
          };
          if (rewardEvent.eventType === "TEST_REWARD_UNLOCKED") counts.unlocked += 1;
          if (rewardEvent.eventType === "TEST_REWARD_RELOCKED") counts.relocked += 1;
          if (rewardEvent.eventType === "TEST_REWARD_REDEEMED") counts.redeemed += 1;
          cycleCounts.set(cycle, counts);
        }
        const availableCycle = [...cycleCounts.entries()]
          .sort(([left], [right]) => left - right)
          .find(([, counts]) =>
            canRedeemEarnedReward(
              counts.unlocked,
              counts.relocked,
              counts.redeemed,
              reward.maximumRedemptionsPerEarned,
            ),
          )?.[0];
        if (!availableCycle)
          throw new AppError(
            "TEST_REWARD_NOT_UNLOCKED",
            "Earn another unlock for this reward before redeeming it again.",
            HttpStatus.CONFLICT,
          );
        const event = await transaction.programTestEvent.create({
          data: {
            sessionId,
            rewardDefinitionId: rewardId,
            eventType: "TEST_REWARD_REDEEMED",
            idempotencyKey,
            amount: 1,
            createdByUserId: userId,
            safeMetadata: { cycle: availableCycle },
          },
        });
        const rewardIds = session.version.rewards.map((item) => item.id);
        const redeemedRewardIds = await transaction.programTestEvent.findMany({
          where: {
            sessionId,
            eventType: "TEST_REWARD_REDEEMED",
            rewardDefinitionId: { in: rewardIds },
            ...sinceReset,
          },
          distinct: ["rewardDefinitionId"],
          select: { rewardDefinitionId: true },
        });
        if (
          session.cycleCount > 0 &&
          redeemedRewardIds.length === rewardIds.length &&
          session.version.revision === session.versionRevision &&
          session.version.validationFingerprint === session.validationFingerprint
        ) {
          await transaction.programTestSession.update({
            where: { id: sessionId },
            data: { status: "COMPLETED" },
          });
          await transaction.loyaltyProgramVersion.update({
            where: { id: session.versionId },
            data: { status: "TEST_READY", testReadyAt: new Date() },
          });
        }
        return event;
      },
    );
  }

  async reverseTestStamp(
    userId: string,
    organizationId: string,
    sessionId: string,
    idempotencyKey: string,
    request: WafloRequest,
  ) {
    await this.tenant.requireMembership(userId, organizationId, "programs.test");
    const result = await withOrganizationInvariantLock(
      this.prisma.client,
      organizationId,
      async (transaction) => {
        const session = await transaction.programTestSession.findFirst({
          where: { id: sessionId, organizationId },
          include: {
            version: {
              include: {
                stampRule: true,
                rewards: { include: { translations: true } },
              },
            },
          },
        });
        if (!session)
          throw new AppError(
            "TEST_SESSION_NOT_FOUND",
            "Test session not found.",
            HttpStatus.NOT_FOUND,
          );
        const replay = await transaction.programTestEvent.findUnique({
          where: { sessionId_idempotencyKey: { sessionId, idempotencyKey } },
        });
        if (replay)
          return transaction.programTestSession.findUniqueOrThrow({
            where: { id: sessionId },
            include: {
              version: {
                include: {
                  stampRule: true,
                  rewards: { include: { translations: true } },
                },
              },
              events: { orderBy: { createdAt: "desc" }, take: 100 },
            },
          });
        const goal = session.version.stampRule?.requiredStampCount ?? 8;
        const currentAbsolute = absoluteTestPosition(
          session.cycleCount,
          session.currentStampCount,
          goal,
        );
        if (currentAbsolute === 0)
          throw new AppError(
            "TEST_STAMP_REVERSE_EMPTY",
            "There is no synthetic stamp to reverse.",
            HttpStatus.CONFLICT,
          );
        const cycle = Math.floor((currentAbsolute - 1) / goal) + 1;
        const positionInCycle = ((currentAbsolute - 1) % goal) + 1;
        const affectedRewards = session.version.rewards.filter(
          (reward) => reward.thresholdStampCount === positionInCycle,
        );
        const latestReset = await transaction.programTestEvent.findFirst({
          where: { sessionId, eventType: "TEST_SESSION_RESET" },
          orderBy: { createdAt: "desc" },
          select: { createdAt: true },
        });
        if (affectedRewards.length) {
          const redemptions = await transaction.programTestEvent.findMany({
            where: {
              sessionId,
              eventType: "TEST_REWARD_REDEEMED",
              rewardDefinitionId: { in: affectedRewards.map((reward) => reward.id) },
              ...(latestReset ? { createdAt: { gt: latestReset.createdAt } } : {}),
            },
            select: { safeMetadata: true },
          });
          const crossesRedeemedReward = redemptions.some((redemption) => {
            const metadata =
              redemption.safeMetadata && typeof redemption.safeMetadata === "object"
                ? (redemption.safeMetadata as { cycle?: unknown })
                : null;
            return metadata?.cycle === cycle;
          });
          if (crossesRedeemedReward)
            throw new AppError(
              "TEST_STAMP_REVERSE_REDEEMED_REWARD",
              "This stamp unlocked a reward that was already redeemed. Reset Test Mode instead.",
              HttpStatus.CONFLICT,
            );
        }
        const nextAbsolute = currentAbsolute - 1;
        const projection = projectAbsoluteTestPosition(nextAbsolute, goal);
        await transaction.programTestEvent.create({
          data: {
            sessionId,
            eventType: "TEST_STAMP_REVERSED",
            amount: 1,
            idempotencyKey,
            createdByUserId: userId,
            safeMetadata: {
              cycle,
              positionInCycle,
              previousAbsolute: currentAbsolute,
              nextAbsolute,
            },
          },
        });
        for (const reward of affectedRewards)
          await transaction.programTestEvent.create({
            data: {
              sessionId,
              eventType: "TEST_REWARD_RELOCKED",
              amount: 1,
              rewardDefinitionId: reward.id,
              idempotencyKey: `${idempotencyKey}:relock:${cycle}:${reward.id}`,
              createdByUserId: userId,
              safeMetadata: { cycle, thresholdStampCount: positionInCycle },
            },
          });
        await transaction.loyaltyProgramVersion.update({
          where: { id: session.versionId },
          data: { status: "VALIDATED", testReadyAt: null },
        });
        return transaction.programTestSession.update({
          where: { id: sessionId },
          data: {
            currentStampCount: projection.currentStampCount,
            cycleCount: projection.cycleCount,
            status: "ACTIVE",
          },
          include: {
            version: {
              include: {
                stampRule: true,
                rewards: { include: { translations: true } },
              },
            },
            events: { orderBy: { createdAt: "desc" }, take: 100 },
          },
        });
      },
    );
    await this.audit.record(
      {
        organizationId,
        actorUserId: userId,
        action: "program.test_stamp_reversed",
        targetType: "program_test_session",
        targetId: sessionId,
      },
      request,
    );
    return result;
  }

  async resetTestSession(
    userId: string,
    organizationId: string,
    sessionId: string,
    request: WafloRequest,
    idempotencyKey: string,
  ) {
    await this.tenant.requireMembership(userId, organizationId, "programs.test");
    const session = await withOrganizationInvariantLock(
      this.prisma.client,
      organizationId,
      async (transaction) => {
        const found = await transaction.programTestSession.findFirst({
          where: { id: sessionId, organizationId },
        });
        if (!found)
          throw new AppError(
            "TEST_SESSION_NOT_FOUND",
            "Test session not found.",
            HttpStatus.NOT_FOUND,
          );
        const existing = await transaction.programTestEvent.findUnique({
          where: { sessionId_idempotencyKey: { sessionId, idempotencyKey } },
        });
        if (existing)
          return transaction.programTestSession.findUniqueOrThrow({
            where: { id: sessionId },
            include: { events: { orderBy: { createdAt: "desc" }, take: 20 } },
          });
        await transaction.programTestEvent.create({
          data: {
            sessionId,
            eventType: "TEST_SESSION_RESET",
            idempotencyKey,
            createdByUserId: userId,
          },
        });
        await transaction.loyaltyProgramVersion.update({
          where: { id: found.versionId },
          data: { status: "VALIDATED", testReadyAt: null },
        });
        return transaction.programTestSession.update({
          where: { id: sessionId },
          data: { currentStampCount: 0, cycleCount: 0, status: "RESET", resetAt: new Date() },
          include: { events: { orderBy: { createdAt: "desc" }, take: 20 } },
        });
      },
    );
    await this.audit.record(
      {
        organizationId,
        actorUserId: userId,
        action: "program.test_session_reset",
        targetType: "program_test_session",
        targetId: sessionId,
      },
      request,
    );
    return session;
  }

  async publish(
    userId: string,
    organizationId: string,
    programId: string,
    idempotencyKey: string,
    request: WafloRequest,
  ) {
    await this.tenant.requireMembership(userId, organizationId, "programs.publish");
    const result = await withOrganizationInvariantLock(
      this.prisma.client,
      organizationId,
      async (transaction) => {
        const replay = await transaction.programPublishCommand.findUnique({
          where: { organizationId_idempotencyKey: { organizationId, idempotencyKey } },
        });
        if (replay) {
          if (replay.programId !== programId)
            throw new AppError(
              "IDEMPOTENCY_KEY_REUSED",
              "This publish idempotency key belongs to another program.",
              HttpStatus.CONFLICT,
            );
          return replay;
        }
        const program = await transaction.loyaltyProgram.findFirst({
          where: { id: programId, organizationId },
          include: { currentDraftVersion: true },
        });
        const version = program?.currentDraftVersion;
        if (
          !program ||
          version?.status !== "TEST_READY" ||
          !version.validationFingerprint ||
          !version.testReadyAt
        )
          throw new AppError(
            "PROGRAM_TEST_REQUIRED",
            "Complete Test Mode after the latest validation before publishing.",
            HttpStatus.CONFLICT,
          );
        const completedTest = await transaction.programTestSession.findFirst({
          where: {
            organizationId,
            versionId: version.id,
            status: "COMPLETED",
            versionRevision: version.revision,
            validationFingerprint: version.validationFingerprint,
          },
          select: { id: true },
        });
        if (!completedTest)
          throw new AppError(
            "PROGRAM_TEST_REQUIRED",
            "Complete the synthetic customer journey before publishing.",
            HttpStatus.CONFLICT,
          );
        const now = new Date();
        const command = await transaction.programPublishCommand.create({
          data: {
            organizationId,
            programId,
            versionId: version.id,
            idempotencyKey,
            status: "PROCESSING",
          },
        });
        const published = await transaction.loyaltyProgramVersion.update({
          where: { id: version.id },
          data: { status: "PUBLISHED", publishedAt: now },
        });
        if (program.currentPublishedVersionId)
          await transaction.loyaltyProgramVersion.update({
            where: { id: program.currentPublishedVersionId },
            data: { status: "SUPERSEDED", supersededAt: now },
          });
        const billing = await transaction.organizationBillingProfile.findUniqueOrThrow({
          where: { organizationId },
        });
        const shouldStartTrial =
          billing.subscriptionStatus === "PENDING_ACTIVATION" && billing.trialStart === null;
        const trialEnd = shouldStartTrial
          ? new Date(now.getTime() + 15 * 24 * 60 * 60 * 1000)
          : null;
        if (shouldStartTrial)
          await transaction.organizationBillingProfile.update({
            where: { organizationId },
            data: {
              subscriptionStatus: "TRIALING",
              trialStart: now,
              trialEnd,
              trialTriggeringProgramId: programId,
              trialTriggeringUserId: userId,
            },
          });
        await transaction.loyaltyProgram.update({
          where: { id: programId },
          data: {
            currentPublishedVersionId: version.id,
            currentDraftVersionId: null,
            status: "PUBLISHED",
            publishedAt: now,
            revision: { increment: 1 },
          },
        });
        const completedCommand = await transaction.programPublishCommand.update({
          where: { id: command.id },
          data: {
            status: "COMPLETED",
            publishedVersionId: published.id,
            trialStarted: shouldStartTrial,
            trialStart: shouldStartTrial ? now : null,
            trialEnd,
            completedAt: new Date(),
          },
        });
        await this.audit.recordInTransaction(
          transaction,
          {
            organizationId,
            actorUserId: userId,
            action: "program.published",
            targetType: "loyalty_program",
            targetId: programId,
            metadata: {
              commandId: completedCommand.id,
              versionId: version.id,
              trialStarted: shouldStartTrial,
            },
          },
          request,
        );
        if (program.currentPublishedVersionId)
          await this.audit.recordInTransaction(
            transaction,
            {
              organizationId,
              actorUserId: userId,
              action: "program.version_superseded",
              targetType: "loyalty_program_version",
              targetId: program.currentPublishedVersionId,
              metadata: {
                commandId: completedCommand.id,
                replacementVersionId: version.id,
              },
            },
            request,
          );
        if (shouldStartTrial)
          await this.audit.recordInTransaction(
            transaction,
            {
              organizationId,
              actorUserId: userId,
              action: "trial.started_by_program_publication",
              targetType: "organization_billing_profile",
              targetId: billing.id,
              metadata: {
                commandId: completedCommand.id,
                programId,
                versionId: version.id,
                trialEnd: trialEnd?.toISOString() ?? null,
              },
            },
            request,
          );
        return completedCommand;
      },
    );
    return result;
  }

  async transition(
    userId: string,
    organizationId: string,
    programId: string,
    action: "pause" | "resume" | "archive" | "restore",
    request: WafloRequest,
  ) {
    await this.tenant.requireMembership(userId, organizationId, "programs.manage_state");
    const state =
      action === "pause"
        ? "PAUSED"
        : action === "resume" || action === "restore"
          ? "PUBLISHED"
          : "ARCHIVED";
    const updated = await withOrganizationInvariantLock(
      this.prisma.client,
      organizationId,
      async (transaction) => {
        const program = await transaction.loyaltyProgram.findFirst({
          where: { id: programId, organizationId },
        });
        if (!program)
          throw new AppError("PROGRAM_NOT_FOUND", "Program not found.", HttpStatus.NOT_FOUND);
        if (action === "pause" && program.status !== "PUBLISHED")
          throw new AppError(
            "PROGRAM_STATE_INVALID",
            "Only published programs can be paused.",
            HttpStatus.CONFLICT,
          );
        if (action === "resume" && program.status !== "PAUSED")
          throw new AppError(
            "PROGRAM_STATE_INVALID",
            "Only paused programs can be resumed.",
            HttpStatus.CONFLICT,
          );
        if (action === "archive" && !["PUBLISHED", "PAUSED"].includes(program.status))
          throw new AppError(
            "PROGRAM_STATE_INVALID",
            "Only live programs can be archived.",
            HttpStatus.CONFLICT,
          );
        if (action === "restore") {
          if (program.status !== "ARCHIVED" || !program.currentPublishedVersionId)
            throw new AppError(
              "PROGRAM_STATE_INVALID",
              "Only archived programs with a published version can be restored.",
              HttpStatus.CONFLICT,
            );
          const organization = await transaction.organization.findUniqueOrThrow({
            where: { id: organizationId },
            select: { selectedPlan: true },
          });
          const usage = await transaction.loyaltyProgram.count({
            where: { organizationId, status: { not: "ARCHIVED" } },
          });
          const decision = canRestoreProgram(toPlan(organization.selectedPlan), usage);
          if (!decision.allowed)
            throw new AppError(
              "PROGRAM_LIMIT_REACHED",
              "Your plan cannot restore another active program.",
              HttpStatus.CONFLICT,
              { limit: decision.limit, currentUsage: decision.currentUsage },
            );
        }
        return transaction.loyaltyProgram.update({
          where: { id: programId },
          data: {
            status: state,
            pausedAt:
              action === "pause"
                ? new Date()
                : action === "resume" || action === "restore"
                  ? null
                  : program.pausedAt,
            archivedAt:
              action === "archive" ? new Date() : action === "restore" ? null : program.archivedAt,
          },
        });
      },
    );
    await this.audit.record(
      {
        organizationId,
        actorUserId: userId,
        action: `program.${action}d`,
        targetType: "loyalty_program",
        targetId: programId,
      },
      request,
    );
    return updated;
  }

  async abandonDraft(
    userId: string,
    organizationId: string,
    programId: string,
    request: WafloRequest,
  ) {
    await this.tenant.requireMembership(userId, organizationId, "programs.edit");
    const result = await withOrganizationInvariantLock(
      this.prisma.client,
      organizationId,
      async (transaction) => {
        const program = await transaction.loyaltyProgram.findFirst({
          where: { id: programId, organizationId },
          include: { currentDraftVersion: true },
        });
        if (!program?.currentDraftVersion)
          throw new AppError(
            "PROGRAM_DRAFT_REQUIRED",
            "There is no editable draft to abandon.",
            HttpStatus.CONFLICT,
          );
        await transaction.loyaltyProgramVersion.update({
          where: { id: program.currentDraftVersion.id },
          data: { status: "ABANDONED", abandonedAt: new Date() },
        });
        return transaction.loyaltyProgram.update({
          where: { id: programId },
          data: { currentDraftVersionId: null },
        });
      },
    );
    await this.audit.record(
      {
        organizationId,
        actorUserId: userId,
        action: "program.draft_abandoned",
        targetType: "loyalty_program",
        targetId: programId,
      },
      request,
    );
    return result;
  }

  private async ensureBuiltInAssets(
    transaction: Prisma.TransactionClient,
    organizationId: string,
    userId: string,
    template: ProgramTemplateDefinition,
  ) {
    const make = async (
      reference: ProgramTemplateDefinition["artwork"]["filled"],
      category: "STAMP_FILLED" | "STAMP_EMPTY" | "STAMP_MILESTONE",
    ) => {
      const artwork = artworkFor(reference);
      if (!artwork)
        throw new AppError(
          "PROGRAM_LIBRARY_ARTWORK_NOT_FOUND",
          "The selected template artwork version is unavailable.",
          HttpStatus.UNPROCESSABLE_ENTITY,
          { ...reference },
        );
      const bytes = canonicalArtworkBytes(artwork);
      const contentDigest = libraryArtworkDigest(artwork);
      const existing = await transaction.merchantAsset.findUnique({
        where: {
          organizationId_sha256Digest: { organizationId, sha256Digest: contentDigest },
        },
      });
      if (existing) return existing;
      return transaction.merchantAsset.create({
        data: {
          organizationId,
          category,
          source: "WAFLO_LIBRARY",
          originalObjectKey: `built-in/v${reference.version}/${contentDigest}.svg`,
          originalFilename: `${reference.code}-v${reference.version}.svg`,
          mimeType: "image/svg+xml",
          fileSize: bytes.length,
          sha256Digest: contentDigest,
          processingStatus: "READY",
          createdByUserId: userId,
          safeMetadata: {
            storage: "waflo-library",
            inlineSvg: bytes.toString("utf8"),
            libraryCode: reference.code,
            libraryVersion: reference.version,
            librarySchemaVersion: LIBRARY_ARTWORK_SCHEMA_VERSION,
            contentDigest,
            license: "Waflo-owned artwork",
          },
        },
      });
    };
    const [filled, empty, milestone] = await Promise.all([
      make(template.artwork.filled, "STAMP_FILLED"),
      make(template.artwork.empty, "STAMP_EMPTY"),
      make(template.artwork.milestone, "STAMP_MILESTONE"),
    ]);
    return { filledId: filled.id, emptyId: empty.id, milestoneId: milestone.id };
  }

  private async assertAssetReferences(
    transaction: Prisma.TransactionClient,
    organizationId: string,
    visual: ProgramCreateInput["visualTheme"],
    rewards: ProgramCreateInput["rewards"] = [],
  ) {
    const ids = [
      ...new Set(
        [
          visual.logoAssetId,
          visual.heroAssetId,
          visual.backgroundAssetId,
          visual.filledStampAssetId,
          visual.emptyStampAssetId,
          visual.defaultMilestoneAssetId,
          ...rewards.map((reward) => reward.visualOverride?.stampAssetId),
        ].filter((value): value is string => Boolean(value)),
      ),
    ];
    if (!ids.length) return;
    const assets = await transaction.merchantAsset.findMany({
      where: { id: { in: ids }, organizationId, archivedAt: null, processingStatus: "READY" },
      select: { id: true, category: true },
    });
    if (assets.length !== ids.length)
      throw new AppError(
        "PROGRAM_ASSET_INVALID",
        "Every selected asset must belong to this organization and be ready.",
        HttpStatus.UNPROCESSABLE_ENTITY,
      );
    const categoryById = new Map(assets.map((asset) => [asset.id, asset.category]));
    const expected: Array<[string | undefined, string[]]> = [
      [visual.logoAssetId ?? undefined, ["LOGO"]],
      [visual.heroAssetId ?? undefined, ["HERO"]],
      [visual.backgroundAssetId ?? undefined, ["BACKGROUND"]],
      [visual.filledStampAssetId ?? undefined, ["STAMP_FILLED"]],
      [visual.emptyStampAssetId ?? undefined, ["STAMP_EMPTY"]],
      [visual.defaultMilestoneAssetId ?? undefined, ["STAMP_MILESTONE"]],
      ...rewards.map(
        (reward) =>
          [reward.visualOverride?.stampAssetId ?? undefined, ["STAMP_MILESTONE"]] as [
            string | undefined,
            string[],
          ],
      ),
    ];
    for (const [id, categories] of expected)
      if (id && !categories.includes(categoryById.get(id) ?? ""))
        throw new AppError(
          "PROGRAM_ASSET_CATEGORY_INVALID",
          "The selected asset does not match the visual role.",
          HttpStatus.UNPROCESSABLE_ENTITY,
        );
  }

  private versionCreateData(
    input: ProgramCreateInput,
    assets: { filledId: string; emptyId: string; milestoneId: string },
    locationIds: string[],
    userId: string,
    template: ProgramTemplateDefinition,
  ) {
    const visual = input.visualTheme;
    return {
      status: "DRAFT" as const,
      editingMode: input.editingMode.toUpperCase() as "QUICK" | "PRO",
      baseTemplateCode: template.code,
      baseTemplateVersion: template.version,
      configurationSchemaVersion: 2,
      createdByUserId: userId,
      translations: {
        create: (["en", "ar"] as const).map((locale) => {
          const translation = input.translations[locale];
          return {
            locale: locale.toUpperCase() as "EN" | "AR",
            programName: translation.programName,
            shortDescription: translation.shortDescription,
            fullDescription: translation.fullDescription ?? null,
            rewardSummary: translation.rewardSummary,
            joinInstructions: translation.joinInstructions ?? null,
            termsAndConditions: translation.termsAndConditions,
            completionMessage: translation.completionMessage,
            rewardUnlockedMessage: translation.rewardUnlockedMessage,
            pausedMessage: translation.pausedMessage ?? null,
          };
        }),
      },
      stampRule: {
        create: {
          requiredStampCount: input.requiredStampCount,
          defaultStampsPerAction: 1,
          maximumStampsPerOperation: 5,
          earningDescription: input.earningDescription,
          resetBehaviorAfterReward: "RESET",
        },
      },
      rewards: {
        create: input.rewards.map((reward) => ({
          thresholdStampCount: reward.thresholdStampCount,
          rewardType: reward.rewardType,
          internalName: reward.internalName,
          sortOrder: reward.sortOrder,
          validityDurationDays: reward.validityDurationDays ?? null,
          requiresManagerApproval: reward.requiresManagerApproval,
          maximumRedemptionsPerEarned: reward.maximumRedemptionsPerEarned,
          translations: {
            create: (["en", "ar"] as const).map((locale) => {
              const translation = reward.translations[locale];
              return {
                locale: locale.toUpperCase() as "EN" | "AR",
                name: translation.name,
                description: translation.description,
                redemptionInstructions: translation.redemptionInstructions ?? null,
              };
            }),
          },
          ...(reward.visualOverride
            ? {
                visualOverride: {
                  create: {
                    stampAssetId: reward.visualOverride.stampAssetId ?? null,
                    accentOverride: reward.visualOverride.accentOverride ?? null,
                  },
                },
              }
            : {}),
        })),
      },
      locations: { create: locationIds.map((locationId) => ({ locationId })) },
      visualTheme: {
        create: {
          backgroundColor: visual.backgroundColor,
          foregroundColor: visual.foregroundColor,
          accentColor: visual.accentColor,
          secondaryColor: visual.secondaryColor,
          mutedColor: visual.mutedColor,
          filledStampAssetId: visual.filledStampAssetId ?? assets.filledId,
          emptyStampAssetId: visual.emptyStampAssetId ?? assets.emptyId,
          ...(visual.logoAssetId ? { logoAssetId: visual.logoAssetId } : {}),
          ...(visual.heroAssetId ? { heroAssetId: visual.heroAssetId } : {}),
          ...(visual.backgroundAssetId ? { backgroundAssetId: visual.backgroundAssetId } : {}),
          defaultMilestoneAssetId: visual.defaultMilestoneAssetId ?? assets.milestoneId,
          layoutType: visual.layoutType,
          layoutConfiguration: visual.layoutConfiguration,
          stampSize: visual.stampSize,
          stampSpacing: visual.stampSpacing,
          borderRadius: visual.borderRadius,
          progressLabelVisible: visual.progressLabelVisible,
          rewardLabelVisible: visual.rewardLabelVisible,
          customerWebVariant: visual.customerWebVariant,
          applePreviewConfig: visual.applePreviewConfig,
          googlePreviewConfig: visual.googlePreviewConfig,
        },
      },
    };
  }

  private inputFromVersion(
    version: NonNullable<Awaited<ReturnType<ProgramsService["get"]>>["currentDraftVersion"]>,
    internalName: string,
  ): ProgramCreateInput {
    const en = version.translations.find((item) => item.locale === "EN");
    const ar = version.translations.find((item) => item.locale === "AR");
    return {
      internalName,
      editingMode: version.editingMode.toLowerCase() as "quick" | "pro",
      templateCode: version.baseTemplateCode ?? undefined,
      templateVersion: version.baseTemplateVersion ?? undefined,
      requiredStampCount: version.stampRule?.requiredStampCount ?? 8,
      earningDescription:
        version.stampRule?.earningDescription ?? "One stamp per qualifying visit.",
      locationIds: version.locations.map((item) => item.locationId),
      translations: {
        en: {
          programName: en?.programName ?? internalName,
          shortDescription: en?.shortDescription ?? "",
          fullDescription: en?.fullDescription ?? undefined,
          rewardSummary: en?.rewardSummary ?? "",
          joinInstructions: en?.joinInstructions ?? undefined,
          termsAndConditions: en?.termsAndConditions ?? "",
          completionMessage: en?.completionMessage ?? "",
          rewardUnlockedMessage: en?.rewardUnlockedMessage ?? "",
          pausedMessage: en?.pausedMessage ?? undefined,
        },
        ar: {
          programName: ar?.programName ?? internalName,
          shortDescription: ar?.shortDescription ?? "",
          fullDescription: ar?.fullDescription ?? undefined,
          rewardSummary: ar?.rewardSummary ?? "",
          joinInstructions: ar?.joinInstructions ?? undefined,
          termsAndConditions: ar?.termsAndConditions ?? "",
          completionMessage: ar?.completionMessage ?? "",
          rewardUnlockedMessage: ar?.rewardUnlockedMessage ?? "",
          pausedMessage: ar?.pausedMessage ?? undefined,
        },
      },
      rewards: version.rewards.map((reward) => ({
        thresholdStampCount: reward.thresholdStampCount,
        rewardType: reward.rewardType,
        internalName: reward.internalName,
        sortOrder: reward.sortOrder,
        validityDurationDays: reward.validityDurationDays,
        requiresManagerApproval: reward.requiresManagerApproval,
        maximumRedemptionsPerEarned: reward.maximumRedemptionsPerEarned,
        visualOverride: reward.visualOverride
          ? {
              stampAssetId: reward.visualOverride.stampAssetId,
              accentOverride: reward.visualOverride.accentOverride,
            }
          : undefined,
        translations: {
          en: {
            name:
              reward.translations.find((item) => item.locale === "EN")?.name ?? reward.internalName,
            description:
              reward.translations.find((item) => item.locale === "EN")?.description ??
              reward.internalName,
          },
          ar: {
            name:
              reward.translations.find((item) => item.locale === "AR")?.name ?? reward.internalName,
            description:
              reward.translations.find((item) => item.locale === "AR")?.description ??
              reward.internalName,
          },
        },
      })),
      visualTheme: (version.visualTheme
        ? {
            backgroundColor: version.visualTheme.backgroundColor,
            foregroundColor: version.visualTheme.foregroundColor,
            accentColor: version.visualTheme.accentColor,
            secondaryColor: version.visualTheme.secondaryColor,
            mutedColor: version.visualTheme.mutedColor,
            filledStampAssetId: version.visualTheme.filledStampAssetId,
            emptyStampAssetId: version.visualTheme.emptyStampAssetId,
            logoAssetId: version.visualTheme.logoAssetId,
            heroAssetId: version.visualTheme.heroAssetId,
            backgroundAssetId: version.visualTheme.backgroundAssetId,
            defaultMilestoneAssetId: version.visualTheme.defaultMilestoneAssetId,
            layoutType: version.visualTheme.layoutType,
            layoutConfiguration: version.visualTheme.layoutConfiguration as Record<string, unknown>,
            stampSize: version.visualTheme.stampSize,
            stampSpacing: version.visualTheme.stampSpacing,
            borderRadius: version.visualTheme.borderRadius,
            progressLabelVisible: version.visualTheme.progressLabelVisible,
            rewardLabelVisible: version.visualTheme.rewardLabelVisible,
            customerWebVariant: version.visualTheme.customerWebVariant as
              | "CARD"
              | "MINIMAL"
              | "HERO",
            applePreviewConfig: version.visualTheme.applePreviewConfig as Record<string, unknown>,
            googlePreviewConfig: version.visualTheme.googlePreviewConfig as Record<string, unknown>,
          }
        : {}) as never,
    };
  }

  private async clearDraftChildren(transaction: Prisma.TransactionClient, versionId: string) {
    const rewards = await transaction.rewardDefinition.findMany({
      where: { versionId },
      select: { id: true },
    });
    const rewardIds = rewards.map((reward) => reward.id);
    if (rewardIds.length) {
      await transaction.rewardTranslation.deleteMany({ where: { rewardId: { in: rewardIds } } });
      await transaction.rewardVisualOverride.deleteMany({ where: { rewardId: { in: rewardIds } } });
      await transaction.rewardDefinition.deleteMany({ where: { versionId } });
    }
    await transaction.programTranslation.deleteMany({ where: { versionId } });
    await transaction.programLocation.deleteMany({ where: { versionId } });
    await transaction.stampRule.deleteMany({ where: { versionId } });
    await transaction.programVisualTheme.deleteMany({ where: { versionId } });
  }

  private async cloneVersionData(
    transaction: Prisma.TransactionClient,
    versionId: string,
    userId: string,
  ) {
    const source = await transaction.loyaltyProgramVersion.findUniqueOrThrow({
      where: { id: versionId },
      include: includeVersion,
    });
    const theme = source.visualTheme;
    return {
      editingMode: source.editingMode,
      baseTemplateCode: source.baseTemplateCode,
      baseTemplateVersion: source.baseTemplateVersion,
      configurationSchemaVersion: source.configurationSchemaVersion,
      stampRule: source.stampRule
        ? {
            create: {
              requiredStampCount: source.stampRule.requiredStampCount,
              defaultStampsPerAction: source.stampRule.defaultStampsPerAction,
              maximumStampsPerOperation: source.stampRule.maximumStampsPerOperation,
              maximumStampsPerCustomerPerDay: source.stampRule.maximumStampsPerCustomerPerDay,
              minimumPurchaseAmountMinor: source.stampRule.minimumPurchaseAmountMinor,
              minimumPurchaseCurrency: source.stampRule.minimumPurchaseCurrency,
              earningDescription: source.stampRule.earningDescription,
              resetBehaviorAfterReward: source.stampRule.resetBehaviorAfterReward,
            },
          }
        : undefined,
      translations: {
        create: source.translations.map((item) => ({
          locale: item.locale,
          programName: item.programName,
          shortDescription: item.shortDescription,
          fullDescription: item.fullDescription,
          rewardSummary: item.rewardSummary,
          joinInstructions: item.joinInstructions,
          termsAndConditions: item.termsAndConditions,
          completionMessage: item.completionMessage,
          rewardUnlockedMessage: item.rewardUnlockedMessage,
          pausedMessage: item.pausedMessage,
        })),
      },
      rewards: {
        create: source.rewards.map((reward) => ({
          thresholdStampCount: reward.thresholdStampCount,
          rewardType: reward.rewardType,
          internalName: reward.internalName,
          sortOrder: reward.sortOrder,
          validityDurationDays: reward.validityDurationDays,
          requiresManagerApproval: reward.requiresManagerApproval,
          maximumRedemptionsPerEarned: reward.maximumRedemptionsPerEarned,
          translations: {
            create: reward.translations.map((item) => ({
              locale: item.locale,
              name: item.name,
              description: item.description,
              redemptionInstructions: item.redemptionInstructions,
            })),
          },
          ...(reward.visualOverride
            ? {
                visualOverride: {
                  create: {
                    stampAssetId: reward.visualOverride.stampAssetId,
                    accentOverride: reward.visualOverride.accentOverride,
                  },
                },
              }
            : {}),
        })),
      },
      locations: {
        create: source.locations.map((item) => ({
          locationId: item.locationId,
          earningEnabled: item.earningEnabled,
          redemptionEnabled: item.redemptionEnabled,
        })),
      },
      visualTheme: theme
        ? {
            create: {
              backgroundColor: theme.backgroundColor,
              foregroundColor: theme.foregroundColor,
              accentColor: theme.accentColor,
              secondaryColor: theme.secondaryColor,
              mutedColor: theme.mutedColor,
              logoAssetId: theme.logoAssetId,
              heroAssetId: theme.heroAssetId,
              backgroundAssetId: theme.backgroundAssetId,
              filledStampAssetId: theme.filledStampAssetId,
              emptyStampAssetId: theme.emptyStampAssetId,
              defaultMilestoneAssetId: theme.defaultMilestoneAssetId,
              layoutType: theme.layoutType,
              layoutConfiguration: theme.layoutConfiguration as object,
              stampSize: theme.stampSize,
              stampSpacing: theme.stampSpacing,
              borderRadius: theme.borderRadius,
              progressLabelVisible: theme.progressLabelVisible,
              rewardLabelVisible: theme.rewardLabelVisible,
              customerWebVariant: theme.customerWebVariant,
              applePreviewConfig: theme.applePreviewConfig as object,
              googlePreviewConfig: theme.googlePreviewConfig as object,
            },
          }
        : undefined,
      createdByUserId: userId,
    };
  }
}

export { templates };
