import { createHash } from "node:crypto";

export type StampLayout = "ROW" | "GRID" | "PATH" | "RING";
export type StampOutputProfile = "CUSTOMER_WEB" | "APPLE_WALLET" | "GOOGLE_WALLET";

export type StampArtwork =
  | { kind: "svg"; content: string; trusted: true }
  | {
      kind: "data-uri";
      value: string;
      mimeType: "image/png" | "image/jpeg" | "image/webp" | "image/svg+xml";
      trusted: true;
    };

export interface StampLayoutConfiguration {
  columns?: number;
  maxPerRow?: number;
  serpentine?: boolean;
  startAngle?: number;
}

export interface StampMilestone {
  position: number;
  artwork: StampArtwork;
  label?: string;
}

export interface StampRenderInput {
  goal: number;
  progress: number;
  layout: StampLayout;
  filledColor: string;
  emptyColor: string;
  accentColor: string;
  backgroundColor?: string;
  foregroundColor?: string;
  label?: string;
  rewardLabel?: string;
  progressLabelVisible?: boolean;
  rewardLabelVisible?: boolean;
  showIndexLabels?: boolean;
  stampSize?: number;
  spacing?: number;
  layoutConfiguration?: StampLayoutConfiguration;
  filledArtwork?: StampArtwork;
  emptyArtwork?: StampArtwork;
  milestones?: StampMilestone[];
  outputProfile?: StampOutputProfile;
}

export interface StampPosition {
  index: number;
  x: number;
  y: number;
  filled: boolean;
}

function escapeXml(value: string): string {
  return value.replace(
    /[&<>"']/g,
    (char) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&apos;" })[char] ?? char,
  );
}

function validColor(value: string, fallback: string): string {
  return /^#[0-9a-f]{6}$/i.test(value) ? value : fallback;
}

function artworkHref(artwork: StampArtwork | undefined): string | null {
  if (!artwork) return null;
  if (artwork.kind === "data-uri") {
    if (!artwork.value.startsWith(`data:${artwork.mimeType};base64,`))
      throw new Error("Artwork data URI does not match its declared MIME type.");
    return artwork.value;
  }
  if (/<script|<foreignObject|on[a-z]+\s*=|javascript:/i.test(artwork.content))
    throw new Error("Unsafe artwork content.");
  return `data:image/svg+xml;base64,${Buffer.from(artwork.content, "utf8").toString("base64")}`;
}

function fallbackArtwork(filled: boolean, filledColor: string, emptyColor: string): StampArtwork {
  const fill = filled ? validColor(filledColor, "#E4572E") : validColor(emptyColor, "#F7F4EE");
  const stroke = filled ? "#7A2A16" : "#AFA79B";
  return {
    kind: "svg",
    trusted: true,
    content: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><path d="M50 4c7 8 14 7 21 5 1 8 7 13 15 15-3 8-1 15 5 21-6 6-8 13-5 21-8 2-14 7-15 15-7-2-14-3-21 5-7-8-14-7-21-5-1-8-7-13-15-15 3-8 1-15-5-21 6-6 8-13 5-21 8-2 14-7 15-15 7 2 14 3 21-5Z" fill="${fill}" stroke="${stroke}" stroke-width="5"/><circle cx="35" cy="40" r="5" fill="${stroke}"/><circle cx="65" cy="40" r="5" fill="${stroke}"/><path d="M34 62c10 8 22 8 32 0" fill="none" stroke="${stroke}" stroke-width="5" stroke-linecap="round"/></svg>`,
  };
}

function clampInteger(
  value: number | undefined,
  minimum: number,
  maximum: number,
  fallback: number,
) {
  if (!Number.isInteger(value)) return fallback;
  return Math.max(minimum, Math.min(maximum, value as number));
}

export function layoutStampPositions(
  goal: number,
  layout: StampLayout,
  size = 48,
  spacing = 8,
  configuration: StampLayoutConfiguration = {},
): StampPosition[] {
  if (!Number.isInteger(goal) || goal < 2 || goal > 30)
    throw new Error("Stamp goal must be between 2 and 30.");
  if (!Number.isFinite(size) || size < 24 || size > 96) throw new Error("Invalid stamp size.");
  if (!Number.isFinite(spacing) || spacing < 0 || spacing > 32)
    throw new Error("Invalid stamp spacing.");

  const positions: StampPosition[] = [];
  const gap = size + spacing;
  const gridColumns = clampInteger(
    configuration.columns,
    2,
    6,
    Math.min(5, Math.max(2, Math.ceil(Math.sqrt(goal)))),
  );
  const rowLength = clampInteger(configuration.maxPerRow, 2, 10, Math.min(10, goal));
  const pathColumns = clampInteger(configuration.columns, 3, 6, Math.min(5, goal));
  const startAngle = ((configuration.startAngle ?? -90) * Math.PI) / 180;

  for (let index = 0; index < goal; index += 1) {
    let x = 0;
    let y = 0;
    if (layout === "ROW") {
      x = (index % rowLength) * gap;
      y = Math.floor(index / rowLength) * gap;
    } else if (layout === "GRID") {
      x = (index % gridColumns) * gap;
      y = Math.floor(index / gridColumns) * gap;
    } else if (layout === "PATH") {
      const row = Math.floor(index / pathColumns);
      const column = index % pathColumns;
      const serpentineColumn =
        configuration.serpentine === false || row % 2 === 0 ? column : pathColumns - 1 - column;
      x = serpentineColumn * gap;
      y = row * gap + Math.sin((column / Math.max(1, pathColumns - 1)) * Math.PI) * spacing;
    } else {
      const radius = Math.max(size * 1.6, (goal * gap) / (Math.PI * 2));
      const angle = (Math.PI * 2 * index) / goal + startAngle;
      x = radius + Math.cos(angle) * radius;
      y = radius + Math.sin(angle) * radius;
    }
    positions.push({ index, x, y, filled: false });
  }
  const minX = Math.min(...positions.map((position) => position.x));
  const minY = Math.min(...positions.map((position) => position.y));
  return positions.map((position) => ({
    ...position,
    x: position.x - minX + size / 2,
    y: position.y - minY + size / 2,
  }));
}

export function renderStampSvg(input: StampRenderInput): {
  svg: string;
  digest: string;
  width: number;
  height: number;
  positions: StampPosition[];
} {
  const size = input.stampSize ?? 48;
  const spacing = input.spacing ?? 8;
  const progress = Math.max(0, Math.min(input.goal, Math.floor(input.progress)));
  const positions = layoutStampPositions(
    input.goal,
    input.layout,
    size,
    spacing,
    input.layoutConfiguration,
  ).map((position) => ({ ...position, filled: position.index < progress }));
  const labelLines = [
    input.progressLabelVisible && input.label ? input.label : null,
    input.rewardLabelVisible && input.rewardLabel ? input.rewardLabel : null,
  ].filter((value): value is string => Boolean(value));
  const labelHeight = labelLines.length ? labelLines.length * 24 + 16 : 0;
  const maxX = Math.max(...positions.map((position) => position.x + size / 2)) + size / 2;
  const maxY = Math.max(...positions.map((position) => position.y + size / 2)) + size / 2;
  const width = Math.ceil(maxX);
  const height = Math.ceil(maxY + labelHeight);
  const filledHref = artworkHref(
    input.filledArtwork ?? fallbackArtwork(true, input.filledColor, input.emptyColor),
  );
  const emptyHref = artworkHref(
    input.emptyArtwork ?? fallbackArtwork(false, input.filledColor, input.emptyColor),
  );
  const milestones = new Map(
    (input.milestones ?? []).map((milestone) => [
      milestone.position - 1,
      { ...milestone, href: artworkHref(milestone.artwork) },
    ]),
  );
  const artwork = positions
    .map((position) => {
      const milestone = milestones.get(position.index);
      const href = milestone?.href ?? (position.filled ? filledHref : emptyHref);
      const debugLabel = input.showIndexLabels
        ? `<text x="${position.x}" y="${position.y + size * 0.12}" text-anchor="middle" font-family="Arial,sans-serif" font-size="${Math.max(10, size / 4)}" fill="${escapeXml(input.accentColor)}">${position.index + 1}</text>`
        : "";
      return `<g data-stamp-index="${position.index}" data-filled="${position.filled}"${milestone ? ` data-milestone="${milestone.position}"` : ""}><image href="${escapeXml(href ?? "")}" x="${position.x - size / 2}" y="${position.y - size / 2}" width="${size}" height="${size}" preserveAspectRatio="xMidYMid meet"/>${debugLabel}</g>`;
    })
    .join("");
  const background = validColor(input.backgroundColor ?? "#FFFFFF", "#FFFFFF");
  const foreground = validColor(input.foregroundColor ?? input.accentColor, "#222222");
  const labels = labelLines
    .map(
      (label, index) =>
        `<text x="16" y="${Math.ceil(maxY + 24 + index * 24)}" font-family="Arial,Noto Sans Arabic,sans-serif" font-size="${index === 0 ? 16 : 14}" fill="${foreground}">${escapeXml(label)}</text>`,
    )
    .join("");
  const profile = input.outputProfile ?? "CUSTOMER_WEB";
  const ariaLabel = escapeXml(
    [...labelLines, `${progress} of ${input.goal} stamps`].filter(Boolean).join(". "),
  );
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" role="img" aria-label="${ariaLabel}" data-output-profile="${profile}"><rect width="100%" height="100%" rx="18" fill="${background}"/>${artwork}${labels}</svg>`;
  return {
    svg,
    digest: createHash("sha256").update(svg).digest("hex"),
    width,
    height,
    positions,
  };
}
