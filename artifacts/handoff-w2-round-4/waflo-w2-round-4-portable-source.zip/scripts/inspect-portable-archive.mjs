import { spawn } from "node:child_process";
import { resolve } from "node:path";

const archive = resolve(process.argv[2] ?? "");
if (!process.argv[2]) throw new Error("Provide the portable archive path.");

const listing = await new Promise((resolvePromise, reject) => {
  const child = spawn("tar", ["-tf", archive], {
    windowsHide: true,
    stdio: ["ignore", "pipe", "inherit"],
  });
  let output = "";
  child.stdout.setEncoding("utf8");
  child.stdout.on("data", (chunk) => {
    output += chunk;
  });
  child.once("error", reject);
  child.once("exit", (code) => {
    if (code === 0) resolvePromise(output);
    else reject(new Error(`tar exited with ${code ?? "no status"}.`));
  });
});

const forbiddenDirectoryNames = new Set([
  ".git",
  ".next",
  ".pnpm-store",
  "dist",
  "docker-volumes",
  "minio-data",
  "node_modules",
  "playwright-report",
  "postgres-data",
  "redis-data",
  "test-results",
]);
const violations = [];
const entries = listing
  .split(/\r?\n/)
  .map((entry) => entry.replaceAll("\\", "/").replace(/^\.?\//, ""))
  .filter(Boolean);
for (const entry of entries) {
  const parts = entry.split("/");
  if (parts.some((part) => forbiddenDirectoryNames.has(part))) violations.push(entry);
  const name = parts.at(-1) ?? "";
  if (name === ".env" || (name.startsWith(".env.") && name !== ".env.example"))
    violations.push(entry);
}
if (violations.length) {
  throw new Error(
    `Portable archive contains forbidden entries:\n${[...new Set(violations)].join("\n")}`,
  );
}
process.stdout.write(
  `Archive inspection passed.\nEntries: ${entries.length}\nForbidden entries: 0\n`,
);
