from pathlib import Path

from PIL import Image, ImageDraw


root = Path(r"C:\waflo\packages\brand\assets\original\Waflo-Brand-System")
paths = sorted(root.rglob("*.png"))
cell_width, cell_height = 360, 270
columns = 4
rows = (len(paths) + columns - 1) // columns
out = Image.new("RGB", (columns * cell_width, rows * cell_height), "#F7F9FF")

for index, path in enumerate(paths):
    with Image.open(path) as source:
        source_size = source.size
        image = source.convert("RGBA")
    image.thumbnail((320, 215))
    canvas = Image.new("RGBA", (cell_width, cell_height), "white")
    canvas.paste(
        image,
        ((cell_width - image.width) // 2, 30 + (215 - image.height) // 2),
        image,
    )
    draw = ImageDraw.Draw(canvas)
    label = str(path.relative_to(root)).replace("\\", "/")
    draw.text((10, 8), label[:52], fill="#241916")
    draw.text((10, 248), f"{source_size[0]}x{source_size[1]}", fill="#76645F")
    out.paste(
        canvas.convert("RGB"),
        ((index % columns) * cell_width, (index // columns) * cell_height),
    )

out.save(Path(r"C:\waflo\tmp\pdfs\brand-assets-contact-sheet.jpg"), quality=90)
