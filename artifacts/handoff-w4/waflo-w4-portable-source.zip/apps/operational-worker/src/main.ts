import "dotenv/config";
import { createCipheriv, createHash, randomBytes, randomUUID } from "node:crypto";
import { resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { DeleteObjectCommand, PutObjectCommand, S3Client } from "@aws-sdk/client-s3";
import { type Environment, parseEnvironment } from "@waflo/config";
import { createCustomerDataKeyring, decryptCustomerValue } from "@waflo/customer-security";
import {
  createPrismaClient,
  type Prisma,
  type PrismaClient,
  queueWalletPassStateChange,
} from "@waflo/database";
import {
  calculateLedgerEntryHash,
  canonicalJson,
  LEDGER_GENESIS_HASH,
  type ProjectionState,
  rebuildProjection,
  reduceProjectionEvent,
  verifyLedgerHashChain,
} from "@waflo/loyalty-ledger";
import { operationalLocalDate } from "@waflo/loyalty-policy";
import {
  createCsv,
  type OperationalExportType,
  operationalDateBucket,
} from "@waflo/operational-analytics";

const LEASE_SECONDS = 90;

function log(event: string, metadata: Record<string, unknown> = {}) {
  process.stdout.write(
    `${JSON.stringify({ level: "info", component: "operational-worker", event, ...metadata })}\n`,
  );
}

function fingerprint(value: unknown): string {
  return createHash("sha256").update(canonicalJson(value), "utf8").digest("hex");
}

function encryptPrivateObject(plaintext: Buffer, objectKey: string, secret: string): Buffer {
  const key = createHash("sha256").update(secret, "utf8").digest();
  const nonce = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", key, nonce);
  cipher.setAAD(Buffer.from(`waflo-private-object:${objectKey}`, "utf8"));
  const ciphertext = Buffer.concat([cipher.update(plaintext), cipher.final()]);
  return Buffer.from(
    [
      "wpo1",
      nonce.toString("base64url"),
      ciphertext.toString("base64url"),
      cipher.getAuthTag().toString("base64url"),
    ].join("."),
    "utf8",
  );
}

function asFilters(value: Prisma.JsonValue): Record<string, string | number | boolean | null> {
  if (!value || typeof value !== "object" || Array.isArray(value)) return {};
  return Object.fromEntries(
    Object.entries(value).filter(
      ([, item]) => ["string", "number", "boolean"].includes(typeof item) || item === null,
    ),
  ) as Record<string, string | number | boolean | null>;
}

interface AggregateAccumulator {
  organizationId: string;
  programId: string;
  programVersionId: string | null;
  locationId: string | null;
  staffMemberId: string | null;
  localDate: string;
  timezone: string;
  enrollments: number;
  activeMemberships: number;
  stampUnitsIssued: number;
  stampOperations: number;
  reversals: number;
  rewardsUnlocked: number;
  rewardsRedeemed: number;
  redemptionReversals: number;
  memberIds: Set<string>;
  completedCycles: number;
  riskSignals: number;
  sourceSequence: number;
}

function aggregateKey(input: {
  organizationId: string;
  programId: string;
  programVersionId: string | null;
  locationId: string | null;
  staffMemberId: string | null;
  localDate: string;
  timezone: string;
}) {
  return [
    input.organizationId,
    input.programId,
    input.programVersionId ?? "-",
    input.locationId ?? "-",
    input.staffMemberId ?? "-",
    input.localDate,
    input.timezone,
  ].join(":");
}

function aggregateFor(
  aggregates: Map<string, AggregateAccumulator>,
  identity: Omit<
    AggregateAccumulator,
    | "enrollments"
    | "activeMemberships"
    | "stampUnitsIssued"
    | "stampOperations"
    | "reversals"
    | "rewardsUnlocked"
    | "rewardsRedeemed"
    | "redemptionReversals"
    | "memberIds"
    | "completedCycles"
    | "riskSignals"
    | "sourceSequence"
  >,
) {
  const key = aggregateKey(identity);
  const existing = aggregates.get(key);
  if (existing) return existing;
  const created: AggregateAccumulator = {
    ...identity,
    enrollments: 0,
    activeMemberships: 0,
    stampUnitsIssued: 0,
    stampOperations: 0,
    reversals: 0,
    rewardsUnlocked: 0,
    rewardsRedeemed: 0,
    redemptionReversals: 0,
    memberIds: new Set<string>(),
    completedCycles: 0,
    riskSignals: 0,
    sourceSequence: 0,
  };
  aggregates.set(key, created);
  return created;
}

function projectionFingerprint(projection: ProjectionState): string {
  return fingerprint({
    currentCycleStampCount: projection.currentCycleStampCount,
    completedCycleCount: projection.completedCycleCount,
    rewardReady: projection.rewardReady,
    projectionVersion: projection.projectionVersion,
    lastSourceEventId: projection.lastSourceEventId,
  });
}

export class OperationalWorker {
  private readonly workerId = `operations-${randomUUID()}`;
  private readonly objectStorage: S3Client;
  private readonly customerKeyring;
  private stopping = false;

  constructor(
    private readonly prisma: PrismaClient,
    private readonly environment: Environment,
  ) {
    this.objectStorage = new S3Client({
      endpoint: environment.OBJECT_STORAGE_ENDPOINT,
      region: environment.OBJECT_STORAGE_REGION,
      forcePathStyle: environment.OBJECT_STORAGE_FORCE_PATH_STYLE,
      credentials: {
        accessKeyId: environment.OBJECT_STORAGE_ACCESS_KEY_ID,
        secretAccessKey: environment.OBJECT_STORAGE_SECRET_ACCESS_KEY,
      },
    });
    this.customerKeyring = createCustomerDataKeyring(environment.CUSTOMER_DATA_ACTIVE_KEY_VERSION, {
      1: environment.CUSTOMER_DATA_ENCRYPTION_KEY_V1,
    });
  }

  async readiness() {
    await this.prisma.$queryRaw`SELECT 1`;
    return { status: "ready" as const };
  }

  async stop() {
    this.stopping = true;
  }

  async run() {
    await this.readiness();
    log("ready");
    while (!this.stopping) {
      const result = await this.runOnce();
      if (Object.values(result).some((value) => value > 0)) log("batch_processed", result);
      await new Promise((resolvePromise) => setTimeout(resolvePromise, 5_000));
    }
  }

  async runOnce() {
    return {
      rewardsExpired: await this.expireRewards(),
      analyticsRows: await this.rebuildAnalytics(),
      exportsProcessed: (await this.processOneExport()) ? 1 : 0,
      privacyRequestsProcessed: (await this.processOnePrivacyRequest()) ? 1 : 0,
      integrityFindings: await this.sampleProjectionIntegrity(),
      cleanupItems: await this.cleanupExpiredState(),
    };
  }

  async expireRewards() {
    const candidates = await this.prisma.rewardEntitlement.findMany({
      where: {
        status: { in: ["AVAILABLE", "PARTIALLY_REDEEMED"] },
        expiresAt: { lte: new Date() },
      },
      include: {
        rewardDefinition: { select: { thresholdStampCount: true } },
        membership: {
          select: {
            enrollmentProgramVersion: {
              select: { stampRule: { select: { requiredStampCount: true } } },
            },
          },
        },
      },
      take: this.environment.REWARD_EXPIRY_BATCH_SIZE,
    });
    let expired = 0;
    for (const entitlement of candidates) {
      const goal =
        entitlement.membership.enrollmentProgramVersion.stampRule?.requiredStampCount ?? 0;
      if (entitlement.rewardDefinition.thresholdStampCount >= goal) {
        await this.ensureRiskSignal({
          organizationId: entitlement.organizationId,
          programId: (
            await this.prisma.membership.findUniqueOrThrow({
              where: { id: entitlement.membershipId },
              select: { programId: true },
            })
          ).programId,
          membershipId: entitlement.membershipId,
          ruleCode: "FINAL_REWARD_EXPIRY_BLOCKED",
          severity: "HIGH",
          score: 85,
          safeEvidence: { entitlementPublicId: entitlement.publicId },
        });
        continue;
      }
      const result = await this.prisma.rewardEntitlement.updateMany({
        where: {
          id: entitlement.id,
          status: { in: ["AVAILABLE", "PARTIALLY_REDEEMED"] },
        },
        data: { status: "EXPIRED" },
      });
      expired += result.count;
    }
    return expired;
  }

  async rebuildAnalytics() {
    const [entries, memberships, risks] = await Promise.all([
      this.prisma.loyaltyLedgerEntry.findMany({
        orderBy: [{ recordedAt: "asc" }, { id: "asc" }],
      }),
      this.prisma.membership.findMany({
        include: {
          enrollmentProgramVersion: {
            select: { operationalTimezone: true },
          },
        },
      }),
      this.prisma.operationalRiskSignal.findMany({
        orderBy: [{ createdAt: "asc" }, { id: "asc" }],
      }),
    ]);
    const membershipById = new Map(memberships.map((item) => [item.id, item]));
    const aggregates = new Map<string, AggregateAccumulator>();
    for (const item of memberships) {
      const timezone = item.enrollmentProgramVersion.operationalTimezone;
      const aggregate = aggregateFor(aggregates, {
        organizationId: item.organizationId,
        programId: item.programId,
        programVersionId: item.enrollmentProgramVersionId,
        locationId: null,
        staffMemberId: null,
        localDate: operationalDateBucket(item.enrolledAt, timezone),
        timezone,
      });
      aggregate.enrollments += 1;
      if (item.status === "ACTIVE") aggregate.activeMemberships += 1;
    }
    for (const entry of entries) {
      const aggregate = aggregateFor(aggregates, {
        organizationId: entry.organizationId,
        programId: entry.programId,
        programVersionId: entry.programVersionId,
        locationId: entry.locationId,
        staffMemberId: entry.staffOrganizationMemberId,
        localDate: entry.operationalLocalDate.toISOString().slice(0, 10),
        timezone: entry.operationalTimezone,
      });
      aggregate.memberIds.add(entry.membershipId);
      aggregate.sourceSequence = Math.max(aggregate.sourceSequence, entry.membershipSequence);
      switch (entry.eventType) {
        case "STAMP_ISSUED":
          aggregate.stampUnitsIssued += entry.stampDelta;
          aggregate.stampOperations += 1;
          break;
        case "STAMP_REVERSED":
          aggregate.reversals += 1;
          break;
        case "MILESTONE_REWARD_UNLOCKED":
        case "FINAL_REWARD_UNLOCKED":
          aggregate.rewardsUnlocked += 1;
          break;
        case "REWARD_REDEEMED":
          aggregate.rewardsRedeemed += 1;
          break;
        case "REWARD_REDEMPTION_REVERSED":
          aggregate.redemptionReversals += 1;
          break;
        case "CYCLE_RESET":
          aggregate.completedCycles += 1;
          break;
        default:
          break;
      }
    }
    for (const risk of risks) {
      const membershipRecord = risk.membershipId
        ? membershipById.get(risk.membershipId)
        : undefined;
      const timezone =
        membershipRecord?.enrollmentProgramVersion.operationalTimezone ?? "Asia/Baghdad";
      const aggregate = aggregateFor(aggregates, {
        organizationId: risk.organizationId,
        programId: risk.programId,
        programVersionId: membershipRecord?.enrollmentProgramVersionId ?? null,
        locationId: risk.locationId,
        staffMemberId: risk.staffMemberId,
        localDate: operationalDateBucket(risk.createdAt, timezone),
        timezone,
      });
      aggregate.riskSignals += 1;
    }
    const rows = [...aggregates.values()].map((aggregate) => ({
      organizationId: aggregate.organizationId,
      programId: aggregate.programId,
      programVersionId: aggregate.programVersionId,
      locationId: aggregate.locationId,
      staffMemberId: aggregate.staffMemberId,
      localDate: new Date(`${aggregate.localDate}T00:00:00.000Z`),
      timezone: aggregate.timezone,
      enrollments: aggregate.enrollments,
      activeMemberships: aggregate.activeMemberships,
      stampUnitsIssued: aggregate.stampUnitsIssued,
      stampOperations: aggregate.stampOperations,
      reversals: aggregate.reversals,
      rewardsUnlocked: aggregate.rewardsUnlocked,
      rewardsRedeemed: aggregate.rewardsRedeemed,
      redemptionReversals: aggregate.redemptionReversals,
      uniqueActiveMembers: aggregate.memberIds.size,
      completedCycles: aggregate.completedCycles,
      riskSignals: aggregate.riskSignals,
      sourceSequence: aggregate.sourceSequence,
    }));
    await this.prisma.$transaction(async (transaction) => {
      await transaction.$queryRaw`
        SELECT 1::int AS locked
        FROM pg_advisory_xact_lock(hashtextextended('waflo-operational-analytics-rebuild', 0))
      `;
      await transaction.operationalDailyAggregate.deleteMany({});
      for (let offset = 0; offset < rows.length; offset += this.environment.ANALYTICS_BATCH_SIZE) {
        await transaction.operationalDailyAggregate.createMany({
          data: rows.slice(offset, offset + this.environment.ANALYTICS_BATCH_SIZE),
        });
      }
    });
    return rows.length;
  }

  async processOneExport() {
    const now = new Date();
    const candidate = await this.prisma.exportCommand.findFirst({
      where: {
        OR: [
          { status: { in: ["PENDING", "FAILED"] } },
          { status: "PROCESSING", leaseExpiresAt: { lt: now } },
        ],
      },
      orderBy: [{ createdAt: "asc" }, { id: "asc" }],
    });
    if (!candidate) return false;
    const claimed = await this.prisma.exportCommand.updateMany({
      where: {
        id: candidate.id,
        OR: [
          { status: { in: ["PENDING", "FAILED"] } },
          { status: "PROCESSING", leaseExpiresAt: { lt: now } },
        ],
      },
      data: {
        status: "PROCESSING",
        leaseOwner: this.workerId,
        leaseExpiresAt: new Date(Date.now() + LEASE_SECONDS * 1_000),
        retryCount: { increment: 1 },
        safeFailureCode: null,
      },
    });
    if (claimed.count !== 1) return false;
    try {
      const rows = await this.exportRows(
        candidate.organizationId,
        candidate.exportType,
        asFilters(candidate.filters),
      );
      if (rows.length > this.environment.EXPORT_MAX_ROWS) {
        throw new Error("EXPORT_ROW_LIMIT_EXCEEDED");
      }
      const content = createCsv(candidate.exportType, rows);
      const objectKey = `private/exports/${candidate.organizationId}/${candidate.publicId}.csv`;
      const encryptedContent = encryptPrivateObject(
        Buffer.from(content, "utf8"),
        objectKey,
        this.environment.OBJECT_STORAGE_SIGNING_SECRET,
      );
      await this.objectStorage.send(
        new PutObjectCommand({
          Bucket: this.environment.OBJECT_STORAGE_BUCKET,
          Key: objectKey,
          Body: encryptedContent,
          ContentType: "application/octet-stream",
          Metadata: {
            exportType: candidate.exportType,
            filterFingerprint: candidate.filterFingerprint,
            encryption: "wpo1-aes-256-gcm",
          },
        }),
      );
      await this.prisma.exportCommand.update({
        where: { id: candidate.id },
        data: {
          status: "COMPLETED",
          objectKey,
          rowCount: rows.length,
          completedAt: new Date(),
          expiresAt: new Date(Date.now() + this.environment.EXPORT_TTL_HOURS * 60 * 60_000),
          leaseOwner: null,
          leaseExpiresAt: null,
        },
      });
    } catch (error) {
      log("export_failed", {
        exportPublicId: candidate.publicId,
        failure:
          error instanceof Error && error.message === "EXPORT_ROW_LIMIT_EXCEEDED"
            ? error.message
            : "EXPORT_BUILD_FAILED",
        diagnostic: error instanceof Error ? error.message.slice(0, 240) : "unknown",
      });
      await this.prisma.exportCommand.update({
        where: { id: candidate.id },
        data: {
          status: "FAILED",
          safeFailureCode:
            error instanceof Error && error.message === "EXPORT_ROW_LIMIT_EXCEEDED"
              ? error.message
              : "EXPORT_BUILD_FAILED",
          leaseOwner: null,
          leaseExpiresAt: null,
        },
      });
    }
    return true;
  }

  private async exportRows(
    organizationId: string,
    exportType: OperationalExportType,
    filters: Record<string, string | number | boolean | null>,
  ): Promise<Array<Record<string, unknown>>> {
    const take = this.environment.EXPORT_MAX_ROWS + 1;
    const programId = typeof filters.programId === "string" ? filters.programId : undefined;
    const locationId = typeof filters.locationId === "string" ? filters.locationId : undefined;
    switch (exportType) {
      case "MEMBERSHIP_SUMMARY": {
        const rows = await this.prisma.membership.findMany({
          where: { organizationId, ...(programId ? { programId } : {}) },
          include: {
            customer: {
              select: {
                displayName: true,
                contacts: {
                  where: { type: "EMAIL", isPrimary: true, archivedAt: null },
                  select: { maskedDisplayValue: true },
                },
              },
            },
            program: { select: { internalName: true } },
            enrollmentProgramVersion: {
              select: {
                versionNumber: true,
                stampRule: { select: { requiredStampCount: true } },
              },
            },
            progress: true,
          },
          take,
          orderBy: [{ enrolledAt: "asc" }, { id: "asc" }],
        });
        return rows.map((item) => ({
          membership_public_id: item.publicMembershipId,
          customer_display_name: item.customer.displayName,
          masked_contact: item.customer.contacts[0]?.maskedDisplayValue ?? "",
          program_name: item.program.internalName,
          program_version: item.enrollmentProgramVersion.versionNumber,
          membership_status: item.status,
          current_stamps: item.progress?.currentCycleStampCount ?? 0,
          goal: item.enrollmentProgramVersion.stampRule?.requiredStampCount ?? 0,
          completed_cycles: item.progress?.completedCycleCount ?? 0,
        }));
      }
      case "LEDGER_OPERATIONS": {
        const rows = await this.prisma.loyaltyLedgerEntry.findMany({
          where: {
            organizationId,
            ...(programId ? { programId } : {}),
            ...(locationId ? { locationId } : {}),
          },
          include: { operationCommand: { select: { publicId: true } } },
          take,
          orderBy: [{ occurredAt: "asc" }, { id: "asc" }],
        });
        const [memberships, locations, members] = await Promise.all([
          this.prisma.membership.findMany({
            where: { id: { in: [...new Set(rows.map((item) => item.membershipId))] } },
            select: { id: true, publicMembershipId: true },
          }),
          this.prisma.location.findMany({
            where: {
              id: { in: rows.flatMap((item) => (item.locationId ? [item.locationId] : [])) },
            },
            select: { id: true, name: true },
          }),
          this.prisma.organizationMember.findMany({
            where: {
              id: {
                in: rows.flatMap((item) =>
                  item.staffOrganizationMemberId ? [item.staffOrganizationMemberId] : [],
                ),
              },
            },
            select: { id: true, user: { select: { displayName: true } } },
          }),
        ]);
        const membershipMap = new Map(
          memberships.map((item) => [item.id, item.publicMembershipId]),
        );
        const locationMap = new Map(locations.map((item) => [item.id, item.name]));
        const staffMap = new Map(members.map((item) => [item.id, item.user.displayName]));
        return rows.map((item) => ({
          operation_public_id: item.operationCommand.publicId,
          membership_public_id: membershipMap.get(item.membershipId) ?? "",
          event_type: item.eventType,
          stamp_delta: item.stampDelta,
          cycle_number: item.cycleNumber,
          sequence: item.membershipSequence,
          location_name: item.locationId ? (locationMap.get(item.locationId) ?? "") : "",
          staff_display_name: item.staffOrganizationMemberId
            ? (staffMap.get(item.staffOrganizationMemberId) ?? "")
            : "",
          occurred_at: item.occurredAt,
        }));
      }
      case "REWARD_REDEMPTIONS": {
        const rows = await this.prisma.rewardRedemption.findMany({
          where: {
            organizationId,
            ...(locationId ? { locationId } : {}),
            ...(programId ? { rewardDefinition: { version: { programId } } } : {}),
          },
          include: {
            rewardDefinition: { select: { internalName: true } },
          },
          take,
          orderBy: [{ redeemedAt: "asc" }, { id: "asc" }],
        });
        const [memberships, locations] = await Promise.all([
          this.prisma.membership.findMany({
            where: { id: { in: [...new Set(rows.map((item) => item.membershipId))] } },
            select: { id: true, publicMembershipId: true },
          }),
          this.prisma.location.findMany({
            where: { id: { in: [...new Set(rows.map((item) => item.locationId))] } },
            select: { id: true, name: true },
          }),
        ]);
        const membershipMap = new Map(
          memberships.map((item) => [item.id, item.publicMembershipId]),
        );
        const locationMap = new Map(locations.map((item) => [item.id, item.name]));
        return rows.map((item) => ({
          redemption_public_id: item.publicId,
          membership_public_id: membershipMap.get(item.membershipId) ?? "",
          reward_name: item.rewardDefinition.internalName,
          cycle_number: item.cycleNumber,
          status: item.status,
          location_name: locationMap.get(item.locationId) ?? "",
          redeemed_at: item.redeemedAt,
        }));
      }
      case "LOCATION_PERFORMANCE":
      case "STAFF_PERFORMANCE":
      case "AGGREGATE_ANALYTICS": {
        const rows = await this.prisma.operationalDailyAggregate.findMany({
          where: {
            organizationId,
            ...(programId ? { programId } : {}),
            ...(locationId ? { locationId } : {}),
          },
          take,
          orderBy: [{ localDate: "asc" }, { id: "asc" }],
        });
        const [programs, locations, members] = await Promise.all([
          this.prisma.loyaltyProgram.findMany({
            where: { id: { in: [...new Set(rows.map((item) => item.programId))] } },
            select: { id: true, internalName: true },
          }),
          this.prisma.location.findMany({
            where: {
              id: { in: rows.flatMap((item) => (item.locationId ? [item.locationId] : [])) },
            },
            select: { id: true, name: true },
          }),
          this.prisma.organizationMember.findMany({
            where: {
              id: {
                in: rows.flatMap((item) => (item.staffMemberId ? [item.staffMemberId] : [])),
              },
            },
            select: { id: true, user: { select: { displayName: true } } },
          }),
        ]);
        const programMap = new Map(programs.map((item) => [item.id, item.internalName]));
        const locationMap = new Map(locations.map((item) => [item.id, item.name]));
        const staffMap = new Map(members.map((item) => [item.id, item.user.displayName]));
        if (exportType === "LOCATION_PERFORMANCE") {
          return rows.map((item) => ({
            location_name: item.locationId ? (locationMap.get(item.locationId) ?? "") : "",
            local_date: item.localDate,
            stamp_units: item.stampUnitsIssued,
            stamp_operations: item.stampOperations,
            rewards_redeemed: item.rewardsRedeemed,
            completed_cycles: item.completedCycles,
            risk_signals: item.riskSignals,
          }));
        }
        if (exportType === "STAFF_PERFORMANCE") {
          return rows.map((item) => ({
            staff_display_name: item.staffMemberId ? (staffMap.get(item.staffMemberId) ?? "") : "",
            local_date: item.localDate,
            stamp_units: item.stampUnitsIssued,
            stamp_operations: item.stampOperations,
            rewards_redeemed: item.rewardsRedeemed,
            reversals: item.reversals,
            risk_signals: item.riskSignals,
          }));
        }
        return rows.map((item) => ({
          local_date: item.localDate,
          program_name: programMap.get(item.programId) ?? "",
          location_name: item.locationId ? (locationMap.get(item.locationId) ?? "") : "",
          enrollments: item.enrollments,
          active_memberships: item.activeMemberships,
          stamp_units: item.stampUnitsIssued,
          rewards_unlocked: item.rewardsUnlocked,
          rewards_redeemed: item.rewardsRedeemed,
          completed_cycles: item.completedCycles,
        }));
      }
      case "RISK_SIGNALS": {
        const rows = await this.prisma.operationalRiskSignal.findMany({
          where: {
            organizationId,
            ...(programId ? { programId } : {}),
            ...(locationId ? { locationId } : {}),
          },
          take,
          orderBy: [{ createdAt: "asc" }, { id: "asc" }],
        });
        return rows.map((item) => ({
          signal_public_id: item.publicId,
          rule_code: item.ruleCode,
          severity: item.severity,
          status: item.status,
          score: item.score,
          created_at: item.createdAt,
          resolved_at: item.resolvedAt,
        }));
      }
    }
  }

  async processOnePrivacyRequest() {
    const candidate = await this.prisma.customerPrivacyRequest.findFirst({
      where: { status: { in: ["PENDING", "FAILED"] } },
      orderBy: [{ createdAt: "asc" }, { id: "asc" }],
    });
    if (!candidate) return false;
    const claimed = await this.prisma.customerPrivacyRequest.updateMany({
      where: { id: candidate.id, status: { in: ["PENDING", "FAILED"] } },
      data: { status: "PROCESSING", failureCode: null },
    });
    if (claimed.count !== 1) return false;
    try {
      if (candidate.requestType === "EXPORT") {
        await this.buildPrivacyExport(candidate);
      } else {
        await this.eraseCustomer(candidate);
      }
    } catch {
      await this.prisma.customerPrivacyRequest.update({
        where: { id: candidate.id },
        data: { status: "FAILED", failureCode: "PRIVACY_PROCESSING_FAILED" },
      });
    }
    return true;
  }

  private async buildPrivacyExport(
    request: Prisma.CustomerPrivacyRequestGetPayload<Record<string, never>>,
  ) {
    const customer = await this.prisma.customer.findFirstOrThrow({
      where: { id: request.customerId, organizationId: request.organizationId },
      include: {
        contacts: true,
        consents: true,
        memberships: {
          include: {
            progress: true,
            program: { select: { internalName: true } },
            rewardEntitlements: { include: { redemptions: true } },
          },
        },
      },
    });
    const ledger = await this.prisma.loyaltyLedgerEntry.findMany({
      where: { customerId: customer.id, organizationId: customer.organizationId },
      orderBy: [{ recordedAt: "asc" }, { id: "asc" }],
      select: {
        publicId: true,
        membershipId: true,
        eventType: true,
        membershipSequence: true,
        cycleNumber: true,
        stampDelta: true,
        occurredAt: true,
        operationalLocalDate: true,
      },
    });
    const payload = {
      generatedAt: new Date().toISOString(),
      customer: {
        id: customer.id,
        displayName: customer.displayName,
        preferredLocale: customer.preferredLocale,
        status: customer.status,
        createdAt: customer.createdAt,
        contacts: customer.contacts.map((contact) => ({
          type: contact.type,
          value: decryptCustomerValue(contact.encryptedValue, {
            organizationId: contact.organizationId,
            recordId: contact.id,
            purpose: "customer-email",
            keyring: this.customerKeyring,
          }),
          verificationStatus: contact.verificationStatus,
        })),
        consents: customer.consents,
        memberships: customer.memberships,
      },
      ledger,
    };
    const objectKey = `private/privacy/${request.organizationId}/${request.publicId}.json`;
    const encryptedContent = encryptPrivateObject(
      Buffer.from(JSON.stringify(payload), "utf8"),
      objectKey,
      this.environment.OBJECT_STORAGE_SIGNING_SECRET,
    );
    await this.objectStorage.send(
      new PutObjectCommand({
        Bucket: this.environment.OBJECT_STORAGE_BUCKET,
        Key: objectKey,
        Body: encryptedContent,
        ContentType: "application/octet-stream",
        Metadata: { encryption: "wpo1-aes-256-gcm", contentType: "application/json" },
      }),
    );
    await this.prisma.customerPrivacyRequest.update({
      where: { id: request.id },
      data: {
        status: "COMPLETED",
        objectKey,
        completedAt: new Date(),
      },
    });
  }

  private async eraseCustomer(
    request: Prisma.CustomerPrivacyRequestGetPayload<Record<string, never>>,
  ) {
    const now = new Date();
    await this.prisma.$transaction(async (transaction) => {
      await transaction.$queryRaw`
        SELECT 1::int AS locked
        FROM pg_advisory_xact_lock(hashtextextended(${`privacy-erasure:${request.customerId}`}, 0))
      `;
      const customer = await transaction.customer.findFirstOrThrow({
        where: { id: request.customerId, organizationId: request.organizationId },
        include: {
          contacts: true,
          memberships: {
            include: {
              progress: true,
              enrollmentProgramVersion: {
                select: {
                  operationalTimezone: true,
                  stampRule: { select: { requiredStampCount: true } },
                },
              },
              walletPassInstances: { select: { id: true } },
            },
          },
        },
      });
      for (const membership of customer.memberships) {
        if (!membership.progress) continue;
        if (membership.status !== "REVOKED") {
          await this.appendPrivacyRevocation(transaction, membership, request.id, now);
        }
        for (const pass of membership.walletPassInstances) {
          await queueWalletPassStateChange(transaction, {
            walletPassInstanceId: pass.id,
            commandType: "INVALIDATE",
            reason: "CUSTOMER_ERASURE",
            eventKey: `privacy-erasure:${request.id}:${membership.id}`,
            safePayload: { privacyRequestPublicId: request.publicId },
          });
        }
      }
      const membershipIds = customer.memberships.map((item) => item.id);
      await transaction.membershipAccessSession.updateMany({
        where: { membershipId: { in: membershipIds }, revokedAt: null },
        data: { revokedAt: now },
      });
      await transaction.membershipCredential.updateMany({
        where: { membershipId: { in: membershipIds }, status: "ACTIVE" },
        data: { status: "REVOKED", revokedAt: now },
      });
      const passIds = customer.memberships.flatMap((item) =>
        item.walletPassInstances.map((pass) => pass.id),
      );
      await transaction.applePassRegistration.updateMany({
        where: { walletPassInstanceId: { in: passIds }, unregisteredAt: null },
        data: {
          pushTokenEncrypted: "erased",
          encryptionKeyVersion: 1,
          unregisteredAt: now,
        },
      });
      await transaction.publicWalletAsset.updateMany({
        where: { membershipId: { in: membershipIds }, revokedAt: null },
        data: { revokedAt: now },
      });
      for (const contact of customer.contacts) {
        const eraseNonce = randomUUID();
        await transaction.customerContact.update({
          where: { id: contact.id },
          data: {
            encryptedValue: `erased:${eraseNonce}`,
            normalizedValueHash: createHash("sha256")
              .update(`erased:${contact.id}:${eraseNonce}`)
              .digest("hex"),
            maskedDisplayValue: "[erased]",
            verificationStatus: "UNVERIFIED",
            verifiedAt: null,
            archivedAt: now,
          },
        });
      }
      await transaction.customerConsent.updateMany({
        where: { customerId: customer.id, revokedAt: null },
        data: { granted: false, revokedAt: now },
      });
      await transaction.customer.update({
        where: { id: customer.id },
        data: {
          displayName: `Erased customer ${fingerprint(customer.id).slice(0, 10)}`,
          status: "ARCHIVED",
          archivedAt: now,
        },
      });
      await transaction.customerPrivacyRequest.update({
        where: { id: request.id },
        data: { status: "COMPLETED", completedAt: now },
      });
      await transaction.auditLog.create({
        data: {
          organizationId: request.organizationId,
          actorUserId: request.requestedByUserId,
          action: "customer.erasure_completed",
          targetType: "customer",
          targetId: customer.id,
          requestId: `privacy-worker:${request.publicId}`,
          metadata: {
            privacyRequestPublicId: request.publicId,
            retainedLedgerHistory: true,
          },
        },
      });
    });
  }

  private async appendPrivacyRevocation(
    transaction: Prisma.TransactionClient,
    membership: Prisma.MembershipGetPayload<{
      include: {
        progress: true;
        enrollmentProgramVersion: {
          select: {
            operationalTimezone: true;
            stampRule: { select: { requiredStampCount: true } };
          };
        };
        walletPassInstances: { select: { id: true } };
      };
    }>,
    privacyRequestId: string,
    occurredAt: Date,
  ) {
    if (!membership.progress || !membership.enrollmentProgramVersion.stampRule) {
      throw new Error("MEMBERSHIP_PROJECTION_MISSING");
    }
    const commandKey = `privacy-erasure:${privacyRequestId}:${membership.id}`;
    const command = await transaction.loyaltyOperationCommand.create({
      data: {
        organizationId: membership.organizationId,
        membershipId: membership.id,
        operationType: "REVOKE_MEMBERSHIP",
        idempotencyKey: commandKey,
        requestFingerprint: fingerprint({ commandKey }),
        status: "PROCESSING",
      },
    });
    const last = await transaction.loyaltyLedgerEntry.findFirst({
      where: { membershipId: membership.id },
      orderBy: { membershipSequence: "desc" },
    });
    const prior: ProjectionState = {
      currentCycleStampCount: membership.progress.currentCycleStampCount,
      completedCycleCount: membership.progress.completedCycleCount,
      rewardReady: membership.progress.rewardReady,
      projectionVersion: membership.progress.projectionVersion,
      lastSourceEventId: membership.progress.lastSourceEventId,
    };
    const sequence = (last?.membershipSequence ?? 0) + 1;
    if (sequence !== prior.projectionVersion + 1) {
      throw new Error("PROJECTION_DRIFT_DETECTED");
    }
    const id = randomUUID();
    const timezone = membership.enrollmentProgramVersion.operationalTimezone;
    const localDate = operationalLocalDate(occurredAt, timezone);
    const payload = {
      id,
      organizationId: membership.organizationId,
      membershipId: membership.id,
      customerId: membership.customerId,
      programId: membership.programId,
      programVersionId: membership.enrollmentProgramVersionId,
      locationId: null,
      staffOrganizationMemberId: null,
      staffDeviceId: null,
      eventType: "MEMBERSHIP_REVOKED" as const,
      membershipSequence: sequence,
      cycleNumber: prior.completedCycleCount + 1,
      stampDelta: 0,
      rewardEntitlementId: null,
      rewardRedemptionId: null,
      reversalOfEntryId: null,
      operationCommandId: command.id,
      purchaseAmountMinor: null,
      purchaseCurrency: null,
      merchantTransactionReference: null,
      operationalTimezone: timezone,
      operationalLocalDate: localDate,
      occurredAt: occurredAt.toISOString(),
      safeMetadata: {
        reason: "CUSTOMER_ERASURE",
        privacyRequestId,
      },
      previousEntryHash: last?.entryHash ?? LEDGER_GENESIS_HASH,
    };
    const entryHash = calculateLedgerEntryHash(payload, this.environment.LEDGER_HASH_SECRET_V1);
    const projection = reduceProjectionEvent(
      prior,
      {
        id,
        eventType: "MEMBERSHIP_REVOKED",
        membershipSequence: sequence,
        cycleNumber: prior.completedCycleCount + 1,
        stampDelta: 0,
      },
      {
        requiredStampCount: membership.enrollmentProgramVersion.stampRule.requiredStampCount,
      },
    );
    await transaction.loyaltyLedgerEntry.create({
      data: {
        ...payload,
        operationalLocalDate: new Date(`${localDate}T00:00:00.000Z`),
        occurredAt,
        ledgerHashVersion: 1,
        entryHash,
      },
    });
    await transaction.membershipProgressProjection.update({
      where: { membershipId: membership.id },
      data: {
        currentCycleStampCount: projection.currentCycleStampCount,
        completedCycleCount: projection.completedCycleCount,
        currentCycleNumber: projection.completedCycleCount + 1,
        rewardReady: projection.rewardReady,
        projectionVersion: projection.projectionVersion,
        lastLedgerSequence: projection.projectionVersion,
        lastSourceEventId: projection.lastSourceEventId,
        projectionFingerprint: projectionFingerprint(projection),
      },
    });
    await transaction.membership.update({
      where: { id: membership.id },
      data: { status: "REVOKED", revokedAt: occurredAt, suspendedAt: null },
    });
    await transaction.loyaltyOperationCommand.update({
      where: { id: command.id },
      data: {
        status: "COMPLETED",
        resultLedgerEntryIds: [id],
        resultProjectionVersion: projection.projectionVersion,
        resultPayload: { status: "REVOKED", privacyErasure: true },
        completedAt: occurredAt,
      },
    });
  }

  async sampleProjectionIntegrity() {
    const memberships = await this.prisma.membership.findMany({
      where: { progress: { isNot: null } },
      include: {
        progress: true,
        enrollmentProgramVersion: {
          select: { stampRule: { select: { requiredStampCount: true } } },
        },
      },
      orderBy: { updatedAt: "asc" },
      take: this.environment.PROJECTION_INTEGRITY_SAMPLE_SIZE,
    });
    let findings = 0;
    for (const membership of memberships) {
      if (!membership.progress || !membership.enrollmentProgramVersion.stampRule) continue;
      const entries = await this.prisma.loyaltyLedgerEntry.findMany({
        where: { membershipId: membership.id },
        orderBy: { membershipSequence: "asc" },
      });
      try {
        verifyLedgerHashChain(
          entries.map((entry) => ({
            id: entry.id,
            organizationId: entry.organizationId,
            membershipId: entry.membershipId,
            customerId: entry.customerId,
            programId: entry.programId,
            programVersionId: entry.programVersionId,
            locationId: entry.locationId,
            staffOrganizationMemberId: entry.staffOrganizationMemberId,
            staffDeviceId: entry.staffDeviceId,
            eventType: entry.eventType,
            membershipSequence: entry.membershipSequence,
            cycleNumber: entry.cycleNumber,
            stampDelta: entry.stampDelta,
            rewardEntitlementId: entry.rewardEntitlementId,
            rewardRedemptionId: entry.rewardRedemptionId,
            reversalOfEntryId: entry.reversalOfEntryId,
            operationCommandId: entry.operationCommandId,
            purchaseAmountMinor: entry.purchaseAmountMinor,
            purchaseCurrency: entry.purchaseCurrency,
            merchantTransactionReference: entry.merchantTransactionReference,
            operationalTimezone: entry.operationalTimezone,
            operationalLocalDate: entry.operationalLocalDate.toISOString().slice(0, 10),
            occurredAt: entry.occurredAt.toISOString(),
            safeMetadata: entry.safeMetadata,
            ledgerHashVersion: 1,
            previousEntryHash: entry.previousEntryHash,
            entryHash: entry.entryHash,
          })),
          (version) =>
            version === this.environment.LEDGER_HASH_ACTIVE_VERSION
              ? this.environment.LEDGER_HASH_SECRET_V1
              : undefined,
        );
        const expected = rebuildProjection(
          entries.map((entry) => ({
            id: entry.id,
            eventType: entry.eventType,
            membershipSequence: entry.membershipSequence,
            cycleNumber: entry.cycleNumber,
            stampDelta: entry.stampDelta,
          })),
          {
            requiredStampCount: membership.enrollmentProgramVersion.stampRule.requiredStampCount,
          },
        );
        const actual: ProjectionState = {
          currentCycleStampCount: membership.progress.currentCycleStampCount,
          completedCycleCount: membership.progress.completedCycleCount,
          rewardReady: membership.progress.rewardReady,
          projectionVersion: membership.progress.projectionVersion,
          lastSourceEventId: membership.progress.lastSourceEventId,
        };
        if (projectionFingerprint(expected) !== projectionFingerprint(actual)) {
          findings += 1;
          await this.ensureRiskSignal({
            organizationId: membership.organizationId,
            programId: membership.programId,
            membershipId: membership.id,
            ruleCode: "PROJECTION_DRIFT",
            severity: "HIGH",
            score: 90,
            safeEvidence: {
              expectedFingerprint: projectionFingerprint(expected),
              actualFingerprint: projectionFingerprint(actual),
            },
          });
        }
      } catch {
        findings += 1;
        await this.ensureRiskSignal({
          organizationId: membership.organizationId,
          programId: membership.programId,
          membershipId: membership.id,
          ruleCode: "LEDGER_INTEGRITY_FAILURE",
          severity: "CRITICAL",
          score: 100,
          safeEvidence: { lastSequence: entries.at(-1)?.membershipSequence ?? 0 },
        });
      }
    }
    return findings;
  }

  private async ensureRiskSignal(input: {
    organizationId: string;
    programId: string;
    membershipId: string;
    ruleCode: string;
    severity: "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";
    score: number;
    safeEvidence: Record<string, unknown>;
  }) {
    const existing = await this.prisma.operationalRiskSignal.findFirst({
      where: {
        organizationId: input.organizationId,
        membershipId: input.membershipId,
        ruleCode: input.ruleCode,
        status: { in: ["OPEN", "ACKNOWLEDGED"] },
      },
      select: { id: true },
    });
    if (existing) return existing;
    return this.prisma.operationalRiskSignal.create({
      data: {
        ...input,
        safeEvidence: input.safeEvidence as Prisma.InputJsonValue,
      },
    });
  }

  async cleanupExpiredState() {
    const now = new Date();
    const [pairings, approvals, nonces, exports] = await this.prisma.$transaction([
      this.prisma.devicePairingSession.updateMany({
        where: { status: { in: ["PENDING", "CLAIMED"] }, expiresAt: { lte: now } },
        data: { status: "EXPIRED" },
      }),
      this.prisma.managerApprovalChallenge.updateMany({
        where: { status: { in: ["PENDING", "APPROVED"] }, expiresAt: { lte: now } },
        data: { status: "EXPIRED" },
      }),
      this.prisma.deviceRequestNonce.deleteMany({ where: { expiresAt: { lte: now } } }),
      this.prisma.exportCommand.findMany({
        where: { status: "COMPLETED", expiresAt: { lte: now } },
        select: { id: true, objectKey: true },
      }),
    ]);
    for (const item of exports) {
      if (item.objectKey) {
        await this.objectStorage
          .send(
            new DeleteObjectCommand({
              Bucket: this.environment.OBJECT_STORAGE_BUCKET,
              Key: item.objectKey,
            }),
          )
          .catch(() => undefined);
      }
      await this.prisma.exportCommand.update({
        where: { id: item.id },
        data: { status: "EXPIRED", objectKey: null },
      });
    }
    return pairings.count + approvals.count + nonces.count + exports.length;
  }
}

async function main() {
  const environment = parseEnvironment(process.env);
  const prisma = createPrismaClient(environment.DATABASE_URL);
  const worker = new OperationalWorker(prisma, environment);
  const shutdown = async () => {
    await worker.stop();
    await prisma.$disconnect();
  };
  process.once("SIGTERM", () => void shutdown());
  process.once("SIGINT", () => void shutdown());
  if (process.argv.includes("--once")) {
    log("one_shot_completed", await worker.runOnce());
    await prisma.$disconnect();
    return;
  }
  await worker.run();
}

if (process.argv[1] && fileURLToPath(import.meta.url) === resolve(process.argv[1])) {
  void main().catch((error: unknown) => {
    process.stderr.write(
      `${error instanceof Error ? error.message : "Operational worker failed."}\n`,
    );
    process.exitCode = 1;
  });
}
