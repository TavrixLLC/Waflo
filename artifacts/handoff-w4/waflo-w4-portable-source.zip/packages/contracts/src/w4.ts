import { z } from "zod";

export const operationCommandIdSchema = z.uuid();
export const safeReasonSchema = z.string().trim().min(3).max(500);

export const staffPairingLocationSchema = z
  .object({
    locationId: z.uuid(),
    earningAllowed: z.boolean(),
    redemptionAllowed: z.boolean(),
  })
  .strict();

export const createDevicePairingSessionSchema = z
  .object({
    staffMemberId: z.uuid(),
    locations: z.array(staffPairingLocationSchema).min(1).max(50),
    deviceLabelSuggestion: z.string().trim().min(1).max(120).optional(),
    expiresInMinutes: z.number().int().min(2).max(30).default(10),
  })
  .strict();

export const devicePairingClaimSchema = z
  .object({
    pairingToken: z.string().min(80).max(512),
    installationId: z.string().trim().min(16).max(160),
    publicKey: z.string().min(40).max(1024),
    platform: z.enum(["IOS", "ANDROID", "TEST_CLIENT"]),
    appVersion: z.string().trim().min(1).max(40),
    osVersion: z.string().trim().max(80).optional(),
    model: z.string().trim().max(120).optional(),
  })
  .strict();

export const devicePairingChallengeSchema = z
  .object({
    pairingPublicId: z.uuid(),
  })
  .strict();

export const devicePairingCompleteSchema = z
  .object({
    pairingPublicId: z.uuid(),
    challenge: z.string().min(32).max(256),
    signature: z.string().min(40).max(256),
    displayName: z.string().trim().min(1).max(120).optional(),
  })
  .strict();

export const staffDeviceSessionRefreshSchema = z
  .object({
    refreshToken: z.string().min(40).max(512),
  })
  .strict();

export const membershipResolveSchema = z
  .object({
    qrPayload: z.string().min(40).max(220),
  })
  .strict();

export const managerOverrideSchema = z
  .object({
    approvalPublicId: z.uuid(),
    dailyCap: z.boolean().default(false),
    purchasePolicy: z.boolean().default(false),
    reason: safeReasonSchema,
  })
  .strict();

export const issueStampSchema = z
  .object({
    qrPayload: z.string().min(40).max(220),
    amount: z.number().int().min(1).max(30),
    purchaseAmountMinor: z.number().int().min(0).max(2_147_483_647).optional(),
    purchaseCurrency: z
      .string()
      .trim()
      .length(3)
      .transform((value) => value.toUpperCase())
      .optional(),
    merchantTransactionReference: z
      .string()
      .trim()
      .min(1)
      .max(120)
      .regex(/^[\p{L}\p{N}._:/ -]+$/u)
      .optional(),
    managerOverride: managerOverrideSchema.optional(),
    clientObservedAt: z.iso.datetime().optional(),
  })
  .strict();

export const redeemRewardSchema = z
  .object({
    qrPayload: z.string().min(40).max(220),
    rewardEntitlementPublicId: z.uuid(),
    managerApprovalPublicId: z.uuid().optional(),
    note: z.string().trim().max(240).optional(),
  })
  .strict();

export const reverseOperationSchema = z
  .object({
    operationPublicId: z.uuid(),
    reason: z.string().trim().max(500).optional(),
  })
  .strict();

export const membershipStatusOperationSchema = z
  .object({
    commandId: operationCommandIdSchema,
    reason: safeReasonSchema,
    locationId: z.uuid(),
  })
  .strict();

export const manualAdjustmentSchema = z
  .object({
    commandId: operationCommandIdSchema,
    stampDelta: z
      .number()
      .int()
      .min(-30)
      .max(30)
      .refine((value) => value !== 0),
    reason: safeReasonSchema,
    locationId: z.uuid(),
  })
  .strict();

export const projectionCommandSchema = z
  .object({
    expectedProjectionVersion: z.number().int().min(0),
  })
  .strict();

export const managerApprovalRequestSchema = z
  .object({
    membershipId: z.uuid(),
    rewardEntitlementId: z.uuid(),
    staffDeviceId: z.uuid(),
    locationId: z.uuid(),
    requestFingerprint: z.string().regex(/^[a-f0-9]{64}$/),
  })
  .strict();

export const managerApprovalDecisionSchema = z
  .object({
    reason: z.string().trim().max(500).optional(),
  })
  .strict();

export const riskSignalDecisionSchema = z
  .object({
    note: safeReasonSchema,
  })
  .strict();

export const createExportSchema = z
  .object({
    exportType: z.enum([
      "MEMBERSHIP_SUMMARY",
      "LEDGER_OPERATIONS",
      "REWARD_REDEMPTIONS",
      "LOCATION_PERFORMANCE",
      "STAFF_PERFORMANCE",
      "RISK_SIGNALS",
      "AGGREGATE_ANALYTICS",
    ]),
    filters: z
      .record(z.string(), z.union([z.string(), z.number(), z.boolean(), z.null()]))
      .default({}),
  })
  .strict();

export const privacyRequestSchema = z
  .object({
    commandId: operationCommandIdSchema,
    confirmation: z.literal("CONFIRM"),
    reasonOrLegalBasis: safeReasonSchema,
  })
  .strict();

export type CreateDevicePairingSessionInput = z.infer<typeof createDevicePairingSessionSchema>;
export type DevicePairingClaimInput = z.infer<typeof devicePairingClaimSchema>;
export type DevicePairingCompleteInput = z.infer<typeof devicePairingCompleteSchema>;
export type IssueStampInput = z.infer<typeof issueStampSchema>;
export type RedeemRewardInput = z.infer<typeof redeemRewardSchema>;
export type ReverseOperationInput = z.infer<typeof reverseOperationSchema>;
